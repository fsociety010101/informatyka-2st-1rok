public class PulsBiznesuArticle implements Event {
    Article article;
    EventType eventType;

    public PulsBiznesuArticle(Article article, EventType eventType) {
        this.article = article;
        this.eventType = eventType;
    }

    @Override
    public Article getArticle() {
        return null;
    }

    @Override
    public EventType getEventType() {
        return null;
    }
}
