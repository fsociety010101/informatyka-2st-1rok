public abstract class Publisher {
    protected Broker broker;

    public Broker getBroker(){ return broker;}

    public void setBroker(Broker broker){
        this.broker = broker;
    }
}
