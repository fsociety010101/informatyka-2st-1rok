public class ArticleCounter implements Subscriber {
    private Integer counter = 0;

    @Override
    public void call(Event event) {
        counter++;
    }
    public Integer getCounter(){ return counter;}
}
