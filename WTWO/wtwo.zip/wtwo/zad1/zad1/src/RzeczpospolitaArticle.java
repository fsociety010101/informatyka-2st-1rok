public class RzeczpospolitaArticle implements Event {
    Article article;
    EventType eventType;

    public RzeczpospolitaArticle(Article article, EventType eventType) {
        this.article = article;
        this.eventType = eventType;
    }

    @Override
    public Article getArticle() {
        return null;
    }

    @Override
    public EventType getEventType() {
        return null;
    }
}
