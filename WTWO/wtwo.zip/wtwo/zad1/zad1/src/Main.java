public class Main {
    public static void main(String[] args) {
        Broker dzien_sport = new Broker();
        Rzeczpospolita rzeczpospolita = new Rzeczpospolita();
        GazetaPrawna gazetaPrawna = new GazetaPrawna();
        PulsBiznesu pulsBiznesu = new PulsBiznesu();
        Broker dzien_fin = new Broker();
        Broker dzien_sled = new Broker();

        dzien_fin.register(pulsBiznesu, EventType.PULS_BIZNESU_ARTICLE_EVENT);
        dzien_sled.register(pulsBiznesu, EventType.PULS_BIZNESU_ARTICLE_EVENT);
        dzien_sled.register(gazetaPrawna, EventType.GAZETA_PRAWNA_ARTICLE_EVENT);
        dzien_sled.register(rzeczpospolita, EventType.RZECZPOSPOLITA_ARTICLE_EVENT);
        dzien_sport.register(gazetaPrawna, EventType.GAZETA_PRAWNA_ARTICLE_EVENT);
        rzeczpospolita.setBroker(dzien_sled);
        gazetaPrawna.setBroker(dzien_sled);
        pulsBiznesu.setBroker(dzien_sled);
        gazetaPrawna.setBroker(dzien_sport);
        pulsBiznesu.setBroker(dzien_fin);

    }
}
