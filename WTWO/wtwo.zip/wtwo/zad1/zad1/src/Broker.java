import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class Broker {
    private HashMap<EventType, List<Subscriber>> observers = new HashMap<>();
    private HashMap<EventType, List<Publisher>> publishers = new HashMap<>();

    public void register(Subscriber observer, EventType eventType){
        if(observers.containsKey(eventType)){
            observers.get(eventType).add(observer);
        }
        else{
            List<Subscriber> obs = new ArrayList<>();
            obs.add(observer);
            observers.put(eventType, obs);
        }
    }

    public void unregister(Subscriber observer, EventType eventType){
        if (observers.containsKey(eventType)){
            observers.get(eventType).remove(observer);
        }
    }

    public void register(Publisher publisher, EventType eventType){
        if (publishers.containsKey(eventType)){
            publishers.get(eventType).add(publisher);
        } else{
            List<Publisher> pubs = new ArrayList<>();
            pubs.add(publisher);
            publishers.put(eventType, pubs);
        }
    }

    public void fire(Publisher publisher, Event event){
        for(Subscriber observer: observers.get(event.getEventType())){
            observer.call(event);
        }
    }
}
