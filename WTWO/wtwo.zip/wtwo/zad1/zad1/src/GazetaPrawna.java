public class GazetaPrawna extends Publisher{

    public void createArticle(){
        Article article = new Article("Legia znajduje sie w I lidze", "15 marca Unia Hrubieszow poteznie " +
                "rozgromila Warszawiakow w meczu pucharu ziemi hrubieszowskiej", "Gazeta Prawna");

        GazetaPrawnaArticle event = new GazetaPrawnaArticle(article, EventType.GAZETA_PRAWNA_ARTICLE_EVENT);
        broker.fire(this, event);
    }
}
