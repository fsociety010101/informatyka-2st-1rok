public interface Subscriber {
    void call(Event event);
}
