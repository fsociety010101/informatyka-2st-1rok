

public class Rzeczpospolita extends Publisher{
    public void createArticle(){
        Article article = new Article("Finanse prezesa Miodulskiego są w załamniu", "Przerwanie lancuchow dostaw podczas pandemii" +
                " ujawnily slaby stan zasobow pienieznych oligarchy. Smutek i niedowierzanie", "Rzeczpospolita");

        RzeczpospolitaArticle event = new RzeczpospolitaArticle(article, EventType.RZECZPOSPOLITA_ARTICLE_EVENT);
        broker.fire(this, event);
    }
}
