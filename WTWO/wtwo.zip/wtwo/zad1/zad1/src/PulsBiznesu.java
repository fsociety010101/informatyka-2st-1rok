public class PulsBiznesu extends Publisher{

    public void createArticle(){
        Article article = new Article("Inflacja urosla do zatrwazajacych rozmiarow", "Polacy narzekaja na wartosc papierkow w portfelu. Okazuje sie, ze Austriacka Szkola Ekonomii " +
                "Miala racje, a Mateusz Morawiecki powinien poczytac Henry'ego Hazlitta i odrzucic Keynesowska polityke monetarna", "Puls Biznesu");

        GazetaPrawnaArticle event = new GazetaPrawnaArticle(article, EventType.PULS_BIZNESU_ARTICLE_EVENT);
        broker.fire(this, event);
    }
}
