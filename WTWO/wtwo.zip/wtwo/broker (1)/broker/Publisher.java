package eventbroker;

import java.util.ArrayList;
import java.util.List;

public abstract class Publisher {
    protected Broker broker;

    public Broker getBroker() {
        return broker;
    }

    public void setBroker(Broker broker) {
        this.broker = broker;
    }
}
