package eventbroker;

public class DailyTelegraphArticleEvent implements Event {
    Article article;
    EventType eventType;

    DailyTelegraphArticleEvent(Article article, EventType eventType){
        this.article = article;
        this.eventType = eventType;
    }

    @Override
    public Article getArticle() {
        return article;
    }

    @Override
    public EventType getEventType() {
        return eventType;
    }
}
