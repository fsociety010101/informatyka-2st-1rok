package eventbroker;

public interface Event {
    Article getArticle();
    EventType getEventType();
}
