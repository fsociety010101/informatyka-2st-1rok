package eventbroker;

import java.nio.charset.Charset;
import java.util.Random;

public class DailyTelegraph extends Publisher {


    public void createArticle(){
        byte[] array = new byte[7];
        new Random().nextBytes(array);
        String generatedString = new String(array, Charset.forName("UTF-8"));
        Article article = new Article("Auth "+generatedString.toUpperCase(), "The "+generatedString.toLowerCase(),
        "It was very "+generatedString+" night.", "Daily Telegraph");
        DailyTelegraphArticleEvent event = new DailyTelegraphArticleEvent(article, EventType.DAILY_TELEGRAPH_ARTICLE_EVENT);
        broker.fire(this, event);
    }
}
