package eventbroker;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;


public class TestEventBroker {
    private DailyTelegraph dt;
    private WashingtonPost wp;
    private PublicationLeader pl;
    private ArticleCounter ac;
    private Broker broker;

    @BeforeEach
    void preparations(){
        broker = new Broker();
        dt = new DailyTelegraph();
        wp = new WashingtonPost();
        pl = new PublicationLeader();
        ac = new ArticleCounter();
        broker.register(pl, EventType.DAILY_TELEGRAPH_ARTICLE_EVENT);
        broker.register(pl, EventType.WASHINGTON_POST_ARTICLE_EVENT);
        broker.register(ac, EventType.DAILY_TELEGRAPH_ARTICLE_EVENT);
        broker.register(ac, EventType.WASHINGTON_POST_ARTICLE_EVENT);
        dt.setBroker(broker);
        wp.setBroker(broker);
        broker.register(dt, EventType.DAILY_TELEGRAPH_ARTICLE_EVENT);
        broker.register(wp, EventType.WASHINGTON_POST_ARTICLE_EVENT);
    }


    @Test
    void testOne(){
        //given

        //when
        dt.createArticle();

        //then
        assertEquals("Daily Telegraph", pl.whoIsTheLeader());
        assertEquals(1, ac.getCounter());
    }

    @Test
    void testCounter(){
        //given
        dt.createArticle();
        wp.createArticle();

        //when
        wp.createArticle();

        //then
        assertEquals(3, ac.getCounter());
    }


    @Test
    void testLeader(){
        //given
        dt.createArticle();
        dt.createArticle();
        wp.createArticle();
        wp.createArticle();

        //when
        wp.createArticle();

        //then
        assertEquals("Washington Post", pl.whoIsTheLeader());
    }
}
