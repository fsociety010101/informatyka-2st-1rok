package eventbroker;

public enum EventType {
    DAILY_TELEGRAPH_ARTICLE_EVENT,
    WASHINGTON_POST_ARTICLE_EVENT
}
