package eventbroker;

import java.nio.charset.Charset;
import java.util.Random;

public class WashingtonPost extends Publisher {

    public void createArticle(){
        byte[] array = new byte[9];
        new Random().nextBytes(array);
        String generatedString = new String(array, Charset.forName("UTF-8"));
        Article article = new Article("George "+generatedString.toUpperCase(), "In the power of "+generatedString.toLowerCase(),
                "Long long "+generatedString+" ago.", "Washington Post");
        WashingtonPostArticleEvent event = new WashingtonPostArticleEvent(article, EventType.WASHINGTON_POST_ARTICLE_EVENT);
        broker.fire(this, event);
    }
}
