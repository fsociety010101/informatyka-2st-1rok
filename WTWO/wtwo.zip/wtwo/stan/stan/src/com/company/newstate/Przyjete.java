package com.company.newstate;

import com.company.temp.WniosekSimulator;

public class Przyjete implements NewState{

    int timer;

    @Override
    public void goNext(WniosekSimulator wniosekSimulator) {
        if (wniosekSimulator.getUrzad().equals("check")) {
            wniosekSimulator.setState(new Przekierowane());
            try{ Thread.sleep(1000);}catch(Exception e){}
            wniosekSimulator.setWniosek("Przekierowane");
        }else if(timer == 3){
            wniosekSimulator.setState(new Zaakceptowane());
            try{ Thread.sleep(1000);}catch(Exception e){}
            wniosekSimulator.setWniosek("Zaakceptowane");
        }else if(wniosekSimulator.getWniosek().equals("aou")){
            wniosekSimulator.setState(new Odrzucone());
            try{ Thread.sleep(1000);}catch(Exception e){}
            wniosekSimulator.setWniosek("Odrzucone");
        }else if(wniosekSimulator.getWniosek().equals("phg")){
            wniosekSimulator.setState(new Anulowany());
            try{ Thread.sleep(1000);}catch(Exception e){}
            wniosekSimulator.setWniosek("Anulowany");
        }
    }
}
