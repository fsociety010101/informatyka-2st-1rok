package com.company;

import com.company.states.Closed;
import com.company.states.Closing;
import com.company.states.Opened;
import com.company.states.Opening;

public class Main{
    public static void main(String[] args) {
        DoorSimulator doorSimulator = new DoorSimulator();
        buttonPressed(doorSimulator);
        // pętla eventow
    }

    public static void buttonPressed(DoorSimulator door) {
        door.setEvent("b");
    }

    public void sensor1Reached(DoorSimulator door) {
        door.setEvent("s1");
    }

    public void sensor2Reached(DoorSimulator door) {
        door.setEvent("s2");
    }

    public void doorline(DoorSimulator door) {
        door.setEvent("ls");
    }

    public void timeout(DoorSimulator door) {
        door.setEvent("time-out");
    }
}
