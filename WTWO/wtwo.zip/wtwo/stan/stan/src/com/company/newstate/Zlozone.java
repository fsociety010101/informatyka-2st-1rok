package com.company.newstate;

import com.company.states.Opening;
import com.company.temp.DaneWniosku;
import com.company.temp.Urzad;
import com.company.temp.Wniosek;
import com.company.temp.WniosekSimulator;

public class Zlozone implements NewState{

    @Override
    public void goNext(WniosekSimulator wniosekSimulator) {
        if (wniosekSimulator.getWniosek().equals("Zlozony") && wniosekSimulator.getTimer()==1) {
            wniosekSimulator.setState(new Przyjete());
            try{ Thread.sleep(1000);}catch(Exception e){}
            wniosekSimulator.setWniosek("Przyjety");
        }
    }
}
