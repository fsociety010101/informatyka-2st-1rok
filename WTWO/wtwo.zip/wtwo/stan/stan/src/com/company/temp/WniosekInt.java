package com.company.temp;

public interface WniosekInt {
    void zloz(DaneWniosku daneWniosku);
    void sprawdz(Wniosek wniosek, Urzad urzad);
}
