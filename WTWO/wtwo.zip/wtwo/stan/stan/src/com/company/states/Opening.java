package com.company.states;


import com.company.DoorSimulator;

public class Opening implements State {
    @Override
    public void goNext(DoorSimulator doorSimulator) {
        if (doorSimulator.getLastEvent().equals("s1")) {
            doorSimulator.stop();
            doorSimulator.setState(new Opened());
            doorSimulator.start();
        }
    }
}