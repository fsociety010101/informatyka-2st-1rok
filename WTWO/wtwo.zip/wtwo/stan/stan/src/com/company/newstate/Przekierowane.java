package com.company.newstate;

import com.company.temp.DaneWniosku;
import com.company.temp.Urzad;
import com.company.temp.Wniosek;
import com.company.temp.WniosekSimulator;

public class Przekierowane implements NewState{

    @Override
    public void goNext(WniosekSimulator wniosekSimulator) {
        if (wniosekSimulator.getUrzad().equals("urzad")) {
            wniosekSimulator.setState(new Przyjete());
            try{ Thread.sleep(1000);}catch(Exception e){}
            wniosekSimulator.setWniosek("Przyjete");
        }
    }
}
