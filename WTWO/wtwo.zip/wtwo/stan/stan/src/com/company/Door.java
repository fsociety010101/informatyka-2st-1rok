package com.company;

public interface Door {
    void open();
    void stop();
    void close();
    void start();
}
