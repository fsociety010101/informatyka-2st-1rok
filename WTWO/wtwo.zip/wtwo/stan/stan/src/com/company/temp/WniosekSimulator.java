package com.company.temp;

import com.company.Door;
import com.company.newstate.NewState;
import com.company.newstate.Przyjete;
import com.company.newstate.Zlozone;
import com.company.states.Closed;
import com.company.states.State;

// Context
public class WniosekSimulator implements WniosekInt {
    private NewState state;
    private String wniosek;
    private Urzad urzad;
    private int timer;

    public WniosekSimulator(){
        this.state = new Przyjete();
    }

    public void start(){
        this.wniosek = "Zlozony";
        this.state.goNext(this);
    }

    public void setWniosek(String wniosek) {
        this.wniosek = wniosek;
    }

    public String getWniosek() {
        return wniosek;
    }

    public Urzad getUrzad() {
        return urzad;
    }

    public int getTimer() {
        return timer;
    }

    public void setState(NewState state) {
        this.state = state;
    }


    @Override
    public void zloz(DaneWniosku daneWniosku) {
        System.out.println("Wniosek zlozony!");
    }

    @Override
    public void sprawdz(Wniosek wniosek, Urzad urzad) {
        System.out.println("Wniosek sprawdzony!");
    }
}
