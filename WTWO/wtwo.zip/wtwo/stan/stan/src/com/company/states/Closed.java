package com.company.states;

import com.company.DoorSimulator;

public class Closed implements State {
    @Override
    public void goNext(DoorSimulator doorSimulator) {
        if (doorSimulator.getLastEvent().equals("b")) {
            doorSimulator.open();
            doorSimulator.setState(new Opening());
            try{ Thread.sleep(1000);}catch(Exception e){}
            doorSimulator.setEvent("s1");
        }
    }
}
