package com.company.states;

import com.company.DoorSimulator;

public class Opened implements State {
    @Override
    public void goNext(DoorSimulator doorSimulator) {
        if (doorSimulator.getLastEvent().equals("time-out")) {
            doorSimulator.close();
            doorSimulator.setState(new Closing());
            try{ Thread.sleep(1000);}catch(Exception e){}
            doorSimulator.setEvent("s2");
        }
    }
}