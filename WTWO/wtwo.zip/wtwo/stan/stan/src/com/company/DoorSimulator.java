package com.company;

import com.company.states.Closed;
import com.company.states.State;

// Context
public class DoorSimulator implements Door {
    private State state;
    private String lastEvent;

    public DoorSimulator(){
        this.state = new Closed();
    }

    public void setEvent(String lastEvent){
        this.lastEvent = lastEvent;
        this.state.goNext(this);
    }

    public String getLastEvent() {
        return lastEvent;
    }

    public void setState(State state) {
        this.state = state;
    }


    @Override
    public void open() {
        System.out.println("Otwieranie drzwi");
    }

    @Override
    public void stop() {
        System.out.println("Zatrzymywanie drzwi");
    }

    @Override
    public void close() {
        System.out.println("Zamykanie drzwi");
    }

    @Override
    public void start() {
        try {
            Thread.sleep(1000);
        } catch(Exception e){}
        setEvent("time-out");
        System.out.println("Odliczanie");
    }
}
