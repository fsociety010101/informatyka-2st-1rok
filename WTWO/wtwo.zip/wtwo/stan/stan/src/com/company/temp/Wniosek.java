package com.company.temp;

public class Wniosek {
}
