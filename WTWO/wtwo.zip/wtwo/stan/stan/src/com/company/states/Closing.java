package com.company.states;

import com.company.DoorSimulator;

public class Closing implements State {
    @Override
    public void goNext(DoorSimulator doorSimulator) {
        if (doorSimulator.getLastEvent().equals("b") ||
                doorSimulator.getLastEvent().equals("ls")) {
            doorSimulator.stop();
            doorSimulator.open();
            doorSimulator.setState(new Opening());
        }

        else if(doorSimulator.getLastEvent().equals("s2")) {
            doorSimulator.stop();
            doorSimulator.setState(new Closed());
        }
    }
}