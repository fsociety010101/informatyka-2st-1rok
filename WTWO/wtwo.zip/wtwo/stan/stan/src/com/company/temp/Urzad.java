package com.company.temp;

public class Urzad {
}
