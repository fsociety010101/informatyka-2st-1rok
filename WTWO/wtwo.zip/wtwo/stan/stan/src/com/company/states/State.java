package com.company.states;

import com.company.DoorSimulator;

public interface State {
    // przełącza między stanami
    void goNext(DoorSimulator doorSimulator);
}
