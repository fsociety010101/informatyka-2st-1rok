package com.company.newstate;

import com.company.DoorSimulator;
import com.company.temp.DaneWniosku;
import com.company.temp.Urzad;
import com.company.temp.Wniosek;
import com.company.temp.WniosekSimulator;

public interface NewState {
    // przełącza między stanami
    void goNext(WniosekSimulator wniosekSimulator);
}
