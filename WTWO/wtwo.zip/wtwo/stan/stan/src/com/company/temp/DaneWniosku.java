package com.company.temp;

public class DaneWniosku {
}
