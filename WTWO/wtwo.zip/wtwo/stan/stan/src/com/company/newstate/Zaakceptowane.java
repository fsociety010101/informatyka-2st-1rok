package com.company.newstate;

import com.company.temp.DaneWniosku;
import com.company.temp.Urzad;
import com.company.temp.Wniosek;
import com.company.temp.WniosekSimulator;

public class Zaakceptowane implements NewState{

    @Override
    public void goNext(WniosekSimulator wniosekSimulator) {
        if (wniosekSimulator.getTimer()==5) {
            wniosekSimulator.setState(new Zamknięty());
            try{ Thread.sleep(1000);}catch(Exception e){}
            wniosekSimulator.setWniosek("Zamknięty");
        }
    }
}
