package com.company.newstate;

import com.company.temp.DaneWniosku;
import com.company.temp.Urzad;
import com.company.temp.Wniosek;
import com.company.temp.WniosekSimulator;

public class Zamknięty implements NewState{

    @Override
    public void goNext(WniosekSimulator wniosekSimulator) {

    }
}
