package chain;

public enum State {
    NEW,
    READY_FOR_COMPLETION,
    WAITING_FOR_COMPLETION,
    WAITING_FOR_ITEMS_AVAILABILITY,
    COMPLETED
}
