package chain;

public abstract class Handler {

    Handler handler;

    Handler(Handler handler){
        this.handler = handler;
    }

    public void handle(Context context){
        if (this.handler != null){
            this.handler.handle(context);
        }
    }

    public void setHandler(Handler handler){
        this.handler = handler;
    }
}
