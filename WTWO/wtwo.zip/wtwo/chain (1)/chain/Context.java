package chain;

public class Context {
    private Order order;
    private Storage storage;

    Context(Order order, Storage storage){
        this.order = order;
        this.storage = storage;
    }

    public Storage getStorage() {
        return storage;
    }

    public Order getOrder(){
        return order;
    }
}
