package chain;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class Order {
    List<Integer> items = new ArrayList<>();
    State state;
    Date lastAvailabilityCheck;

    Order(){
        this.state = State.NEW;
    }

    public void addItem(Integer idOfItem){
        items.add(idOfItem);
    }

    public List<Integer> getItems() {
        return new ArrayList<>(this.items);
    }

    public State getState(){
        return this.state;
    }

    public void setState(State state) {
        this.state = state;
    }

    public void setItems(List<Integer> items) {
        this.items = items;
    }

    public Date getLastAvailabilityCheck() {
        return lastAvailabilityCheck;
    }

    public void setLastAvailabilityCheck(Date lastAvailabilityCheck) {
        this.lastAvailabilityCheck = lastAvailabilityCheck;
    }
}
