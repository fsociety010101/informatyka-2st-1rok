package chain;

import java.util.Date;

public class AvailabilityChecker extends Handler {

    Date lastDelivery;

    AvailabilityChecker(Handler handler){
        super(handler);
    }

    @Override
    public void handle(Context context) {
        if (State.WAITING_FOR_COMPLETION.equals(context.getOrder().getState())) {
            boolean itemsAvailable = true;
            for (Integer item : context.getOrder().getItems()) {
                Integer acc = context.getStorage().popItem(item);
                itemsAvailable = itemsAvailable && (acc > 0);
            }
            if (itemsAvailable) {
                context.getOrder().setState(State.READY_FOR_COMPLETION);
            } else {
                for (Integer item : context.getOrder().getItems()) {
                    context.getStorage().releaseItem(item);
                }
                context.getOrder().setState(State.WAITING_FOR_ITEMS_AVAILABILITY);
                context.getOrder().setLastAvailabilityCheck(new Date());
            }
        } else if (State.WAITING_FOR_ITEMS_AVAILABILITY.equals(context.getOrder().getState())){
            if (context.getStorage().isNewDelivery(context.getOrder().getLastAvailabilityCheck())) {
                context.getOrder().setState(State.WAITING_FOR_COMPLETION);
            }
        } else {
            super.handle(context);
        }
    }
}
