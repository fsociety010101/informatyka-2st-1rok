package chain;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;


public class TestChain {
    private static Handler chain;

    @BeforeAll
    static void prepareChain(){
        chain = new EmptinessChecker(new AvailabilityChecker(new OrderCollector(null)));
    }

    @Test
    void testNew(){
        //given
        Storage storage = new Storage();
        Order order = new Order();
        order.addItem(1);
        order.addItem(3);

        //when
        Context context = new Context(order, storage);

        //then
        State state = context.getOrder().getState();
        assertEquals(State.NEW, state);
    }

    @Test
    void testWaitingForCompletion(){
        //given
        Storage storage = new Storage();
        Order order = new Order();
        order.addItem(1);
        order.addItem(3);
        Context context = new Context(order, storage);

        //when
        chain.handle(context);

        //then
        State state = context.getOrder().getState();
        assertEquals(State.WAITING_FOR_COMPLETION, state);
    }

    @Test
    void testReadyForCompletion(){
        //given
        Storage storage = new Storage();
        Order order = new Order();
        order.addItem(1);
        order.addItem(3);
        Context context = new Context(order, storage);
        chain.handle(context);

        //when
        chain.handle(context);

        //then
        State state = context.getOrder().getState();
        assertEquals(State.READY_FOR_COMPLETION, state);
    }

    @Test
    void testCompleted(){
        //given
        Storage storage = new Storage();
        Order order = new Order();
        order.addItem(1);
        order.addItem(3);
        Context context = new Context(order, storage);
        chain.handle(context);
        chain.handle(context);

        //when
        chain.handle(context);

        //then
        State state = context.getOrder().getState();
        assertEquals(State.COMPLETED, state);
    }

    @Test
    void testWaitingForCompletion_not_sufficient(){
        //given
        Storage storage = new Storage();
        Order order = new Order();
        order.addItem(4);
        order.addItem(4);
        Context context = new Context(order, storage);

        //when
        chain.handle(context);

        //then
        State state = context.getOrder().getState();
        assertEquals(State.WAITING_FOR_COMPLETION, state);
    }

    @Test
    void testWaitingForItemsAvailability(){
        //given
        Storage storage = new Storage();
        Order order = new Order();
        order.addItem(4);
        order.addItem(4);
        Context context = new Context(order, storage);
        chain.handle(context);

        //when
        chain.handle(context);

        //then
        State state = context.getOrder().getState();
        assertEquals(State.WAITING_FOR_ITEMS_AVAILABILITY, state);
    }

}
