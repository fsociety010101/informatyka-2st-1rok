package chain;

public class OrderCollector extends Handler {

    OrderCollector(Handler handler){
        super(handler);
    }

    @Override
    public void handle(Context context) {
        if (State.READY_FOR_COMPLETION.equals(context.getOrder().getState())) {
            for (Integer item : context.getOrder().getItems()) {
                context.getStorage().confirm(item);
            }
            context.getOrder().setState(State.COMPLETED);
        } else {
            super.handle(context);
        }
    }
}
