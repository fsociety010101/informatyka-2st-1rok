package chain;

import java.util.Date;
import java.util.HashMap;

public class Storage {
    private static HashMap<Integer, Integer> items = new HashMap<>();
    private static HashMap<Integer, Integer> reservedItems = new HashMap<>();
    private Date latestDelivery;

    Storage(){
        items.put(1, 12);
        items.put(2, 20);
        items.put(3, 3);
        items.put(4, 1);
        for (Integer item: items.keySet()){
            reservedItems.put(item, 0);
        }
    }

    public void updateStorage(Integer item, Integer change){
        this.latestDelivery = new Date();
        items.put(item, items.get(item) + change);
    }

    public Integer popItem(Integer item){
        Integer acc = items.get(item);
        Integer reserved = acc > 0 ? 1: 0;
        items.put(item, acc - reserved);
        reservedItems.put(item, reservedItems.get(item) + reserved);
        return reserved;
    }

    public void releaseItem(Integer item){
        if (reservedItems.get(item) > 0){
            reservedItems.put(item, reservedItems.get(item) - 1);
            items.put(item, items.get(item) + 1);
        }
    }

    public boolean isNewDelivery(Date timestamp){
        return (this.latestDelivery.after(timestamp));
    }

    public void confirm(Integer item){
        reservedItems.put(item, reservedItems.get(item) - 1);
    }
}
