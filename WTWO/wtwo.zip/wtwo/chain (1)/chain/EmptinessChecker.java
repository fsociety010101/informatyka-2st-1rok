package chain;

public class EmptinessChecker extends Handler {

    EmptinessChecker(Handler handler){
        super(handler);
    }

    @Override
    public void handle(Context context) {
        if (State.NEW.equals(context.getOrder().getState())) {
            if (context.getOrder().getItems().size() > 0) {
                context.getOrder().setState(State.WAITING_FOR_COMPLETION);
            }
        } else {
            super.handle(context);
        }
    }
}
