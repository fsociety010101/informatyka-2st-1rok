package com.company.observers;

import com.company.Change;

public interface Observer {
    void update(Change change);
}
