package com.company;

public enum Type {
    WIND, TEMPERATURE;
}
