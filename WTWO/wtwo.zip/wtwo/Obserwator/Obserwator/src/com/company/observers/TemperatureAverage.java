package com.company.observers;

import com.company.Change;
import com.company.Type;

import java.util.*;

// Obserwator
public class TemperatureAverage implements Observer {
    private double temperature = 0;
    private int position = 0;
    private ArrayList<Double> temperatureLogs = new ArrayList<>(5);

    @Override
    public void update(Change change){
        if(change.getType() == Type.TEMPERATURE) {
            temperature = change.getData();
            position %= 5;
            temperatureLogs.add(position, temperature);
        }
    }

    public double getTemperature() {
        double temp = 0.0;
        int counter = 0;

            for(Double d : temperatureLogs) {
                temp += d;
                ++counter;
            }

        return temp/counter;
    }
}
