package com.company;

import com.company.observers.TemperatureAverage;
import com.company.observers.WindChill;
import com.company.producers.Temperature;
import com.company.producers.Wind;

public class Main {

    public static void main(String[] args) {
        // Observators
        TemperatureAverage temperatureAverage = new TemperatureAverage();
        WindChill windChill = new WindChill();

	    // Producers
	    Temperature temperature = new Temperature();
	    Wind wind = new Wind();

        // Subscribe
        temperature.subscribe(temperatureAverage);
        temperature.subscribe(windChill);
        wind.subscribe(windChill);

        // Tests
        for(int i=0; i<100; ++i) {
            temperature.createTemperature();
            System.out.format("TEMP AVG: %.2f °C\n",temperatureAverage.getTemperature());

            wind.createWind();
            System.out.println("WIND: " + windChill.getWindSpeed() + " m/s");
            System.out.println("REAL FEEL TEMP: " + windChill.getRealFeelTemperature() + " °C");

            System.out.println("\n\n");
        }

//        temperature.createTemperature();
//        System.out.println("TEMP AVG: " + temperatureAverage.getTemperature() + " °C");
//
//        wind.createWind();
//        System.out.println("WIND: " + windChill.getWindSpeed() + " m/s");
//        System.out.println("REAL FEEL TEMP: " + windChill.getRealFeelTemperature() + " °C");
    }
}
