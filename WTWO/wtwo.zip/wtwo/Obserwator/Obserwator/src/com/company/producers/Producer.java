package com.company.producers;

import com.company.Change;
import com.company.observers.Observer;

import java.util.ArrayList;

// PUBLISHER
public abstract class Producer {

    private ArrayList<Observer> observers = new ArrayList<>();

    public void subscribe(Observer observer){
        this.observers.add(observer);
    }

    public void unsubscribe(Observer observer){
        this.observers.remove(observer);
    }

    public void notify(Change change){
        for(Observer observer : this.observers)
            observer.update(change);
    }
}
