package com.company;

public class Change {
    private double data;
    private Type type;

    public Change(double data, Type type){this.data = data; this.type = type;}

    public double getData() {return this.data;}

    public Type getType() {
        return type;
    }
}
