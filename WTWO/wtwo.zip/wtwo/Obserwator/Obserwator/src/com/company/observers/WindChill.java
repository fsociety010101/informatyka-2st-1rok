package com.company.observers;

import com.company.Change;
import com.company.Type;

public class WindChill implements Observer {
    private double wind = 0;
    private double realFeelTemperature = 0;

    @Override
    public void update(Change change) {
        if(change.getType() == Type.WIND)
            wind = change.getData();
        if(change.getType() == Type.TEMPERATURE) {
            double currTemp = change.getData();
            realFeelTemperature = currTemp - calculateDiff();
        }
    }

    private double calculateDiff(){
        return wind/100*5;
    }

    public double getWindSpeed() {
        return wind;
    }

    public double getRealFeelTemperature(){
        return realFeelTemperature;
    }
}
