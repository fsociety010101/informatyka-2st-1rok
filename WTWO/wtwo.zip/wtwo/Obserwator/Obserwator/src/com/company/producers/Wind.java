package com.company.producers;

import com.company.Change;
import com.company.Type;

import java.util.Random;

public class Wind extends Producer {
    public void createWind(){
        Random random = new Random();
        int windSpeed = random.nextInt(99);
        Change change = new Change(windSpeed, Type.WIND);
        this.notify(change);
    }
}
