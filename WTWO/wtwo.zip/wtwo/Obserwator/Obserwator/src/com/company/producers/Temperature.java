package com.company.producers;

import com.company.Change;
import com.company.Type;

import java.util.Random;

public class Temperature extends Producer {
    
    public void createTemperature(){
        Random random = new Random();
        int temperature = random.nextInt(60)-30;
        Change change = new Change(temperature, Type.TEMPERATURE);
        this.notify(change);
    }
}
