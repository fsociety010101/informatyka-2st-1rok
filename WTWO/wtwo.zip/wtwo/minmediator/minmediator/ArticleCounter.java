package mediator;

public class ArticleCounter{
    Mediator mediator;

    ArticleCounter(Mediator mediator){
        this.mediator = mediator;
    }

    private Integer counter = 0;

    public void update(Article article) {
        counter++;
    }

    public Integer getCounter() {
        return counter;
    }
}
