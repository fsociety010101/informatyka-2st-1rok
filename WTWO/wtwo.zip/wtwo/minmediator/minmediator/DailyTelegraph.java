package mediator;

import java.nio.charset.Charset;
import java.util.Random;

public class DailyTelegraph{
    Mediator mediator;

    DailyTelegraph(Mediator mediator){
        this.mediator = mediator;
    }

    public void createArticle(){
        byte[] array = new byte[7];
        new Random().nextBytes(array);
        String generatedString = new String(array, Charset.forName("UTF-8"));
        Article article = new Article("Auth "+generatedString.toUpperCase(), "The "+generatedString.toLowerCase(),
        "It was very "+generatedString+" night.", "Daily Telegraph");
        mediator.storeArticle(article);
    }
}
