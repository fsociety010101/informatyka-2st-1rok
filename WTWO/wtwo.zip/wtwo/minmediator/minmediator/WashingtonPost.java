package mediator;

import java.nio.charset.Charset;
import java.util.Random;

public class WashingtonPost{
    Mediator mediator;

    WashingtonPost(Mediator mediator){
        this.mediator = mediator;
    }

    public void createArticle(){
        byte[] array = new byte[9];
        new Random().nextBytes(array);
        String generatedString = new String(array, Charset.forName("UTF-8"));
        Article article = new Article("George "+generatedString.toUpperCase(), "In the power of "+generatedString.toLowerCase(),
                "Long long "+generatedString+" ago.", "Washington Post");
        mediator.storeArticle(article);
    }
}
