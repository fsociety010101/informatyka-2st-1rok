package mediator;

public class Mediator {
    PublicationLeader publicationLeader;
    ArticleCounter articleCounter;
    WashingtonPost washingtonPost;
    DailyTelegraph dailyTelegraph;


    Mediator(){

    }

    public void setPublicationLeader(PublicationLeader publicationLeader) {
        this.publicationLeader = publicationLeader;
    }

    public void setArticleCounter(ArticleCounter articleCounter) {
        this.articleCounter = articleCounter;
    }

    public void setWashingtonPost(WashingtonPost washingtonPost) {
        this.washingtonPost = washingtonPost;
    }

    public void setDailyTelegraph(DailyTelegraph dailyTelegraph) {
        this.dailyTelegraph = dailyTelegraph;
    }

    public void storeArticle(Article article){
        publicationLeader.update(article);
        articleCounter.update(article);
    }
}
