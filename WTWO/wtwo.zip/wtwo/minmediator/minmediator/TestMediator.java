package mediator;


import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;


public class TestMediator {
    private DailyTelegraph dt;
    private WashingtonPost wp;
    private PublicationLeader pl;
    private ArticleCounter ac;

    @BeforeEach
    void preparations(){
        Mediator mediator = new Mediator();
        dt = new DailyTelegraph(mediator);
        wp = new WashingtonPost(mediator);
        pl = new PublicationLeader(mediator);
        ac = new ArticleCounter(mediator);
        mediator.setArticleCounter(ac);
        mediator.setDailyTelegraph(dt);
        mediator.setPublicationLeader(pl);
        mediator.setWashingtonPost(wp);
    }


    @Test
    void testOne(){
        //given

        //when
        dt.createArticle();

        //then
        assertEquals("Daily Telegraph", pl.whoIsTheLeader());
        assertEquals(1, ac.getCounter());
    }

    @Test
    void testCounter(){
        //given
        dt.createArticle();
        wp.createArticle();

        //when
        wp.createArticle();

        //then
        assertEquals(3, ac.getCounter());
    }


    @Test
    void testLeader(){
        //given
        dt.createArticle();
        dt.createArticle();
        wp.createArticle();
        wp.createArticle();

        //when
        wp.createArticle();

        //then
        assertEquals("Washington Post", pl.whoIsTheLeader());
    }
}
