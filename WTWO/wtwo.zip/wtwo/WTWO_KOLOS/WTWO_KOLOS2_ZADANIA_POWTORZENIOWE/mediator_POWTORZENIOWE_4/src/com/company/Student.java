package com.company;

import com.company.mediator.Mediator;

public class Student {
    private final int ID;
    private Mediator mediator;

    public Student(int ID, Mediator mediator){
        this.ID = ID;
        this.mediator = mediator;
    }

    public void sendMessageToProwadzacy(){
        int prowadzacyID = 0;
        mediator.sendMessageAsStudentToProwadzacy("Wiadomosc od studenta od ID " + ID + " do prowadzacego o ID " + prowadzacyID, prowadzacyID);
    }

    public void sendMessageToStudent(){
        int studentReceiverID = 1;
        mediator.sendMessageAsStudentToStudent("Wiadomosc od studenta o ID " + ID + " do studenta o ID " + studentReceiverID, studentReceiverID);
    }

    public void createPost(){
        mediator.createPostAsStudent(this.ID, "Post studenta o ID " + this.ID);
    }

    public int getID() {
        return ID;
    }

    public void update(String msg){
        System.out.println("Student o ID " + this.ID + " otrzymal wiadomosc >>> " + msg);
    }
}
