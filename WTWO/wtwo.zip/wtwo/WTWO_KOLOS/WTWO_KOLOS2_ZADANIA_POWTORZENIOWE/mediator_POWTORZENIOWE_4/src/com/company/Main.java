package com.company;

import com.company.mediator.Mediator;

public class Main {

    public static void main(String[] args) {
        Mediator mediator = new Mediator();

        Student s1 = new Student(mediator.getNewStudentId(), mediator);
        mediator.addStudent(s1);
        Student s2 = new Student(mediator.getNewStudentId(), mediator);
        mediator.addStudent(s2);
        Student s3 = new Student(mediator.getNewStudentId(), mediator);
        mediator.addStudent(s3);

        Prowadzacy p1 = new Prowadzacy(mediator.getNewProwadzacyId(), mediator);
        mediator.addProwadzacy(p1);

        p1.sendMessageToStudent();
        p1.createPost();

        s1.sendMessageToProwadzacy();
    }
}
