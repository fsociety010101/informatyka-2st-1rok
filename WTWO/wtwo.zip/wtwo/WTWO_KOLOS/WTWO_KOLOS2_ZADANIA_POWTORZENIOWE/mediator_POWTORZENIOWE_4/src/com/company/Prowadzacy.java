package com.company;

import com.company.mediator.Mediator;

public class Prowadzacy {
    private final int ID;
    private Mediator mediator;

    public Prowadzacy(int ID, Mediator mediator){
        this.ID = ID;
        this.mediator = mediator;
    }

    public void sendMessageToStudent(){
        int studentID = 1;
        mediator.sendMessageAsProwadzacy("Wiadomosc od prowadzacego o ID " + ID + " do studenta o ID " + studentID, studentID);
    }

    public void createPost(){
        mediator.createPostAsProwadzacy("Post prowadzacego o ID " + this.ID);
    }

    public void update(String msg){
        System.out.println("Prowadzacy o ID " + ID + " otrzymal wiadomosc >>> " + msg);
    }
}
