package com.company.mediator;

import com.company.Prowadzacy;
import com.company.Student;

import java.util.ArrayList;

public class Mediator {
    private ArrayList<Student> studentArrayList = new ArrayList<>();
    private ArrayList<Prowadzacy> prowadzacyArrayList = new ArrayList<>();

    public void addStudent(Student student){
        studentArrayList.add(student);
    }

    public void addProwadzacy(Prowadzacy prowadzacy){
        prowadzacyArrayList.add(prowadzacy);
    }

    public void createPostAsProwadzacy(String post){
        for(Student student : studentArrayList){
            student.update(post);
        }
    }
    public void sendMessageAsProwadzacy(String message, int studentId){
        studentArrayList.get(studentId).update(message);
    }

    public void sendMessageAsStudentToProwadzacy(String message, int prowadzacyId){
        prowadzacyArrayList.get(prowadzacyId).update(message);
    }
    public void sendMessageAsStudentToStudent(String message, int studentReceiverId){
        studentArrayList.get(studentReceiverId).update(message);
    }
    public void createPostAsStudent(int studentId, String post){
        for (Student student : studentArrayList){
            if(student.getID() != studentId)
                student.update(post);
        }
    }

    public int getNewStudentId(){
        return studentArrayList.size();
    }

    public int getNewProwadzacyId(){
        return prowadzacyArrayList.size();
    }
}
