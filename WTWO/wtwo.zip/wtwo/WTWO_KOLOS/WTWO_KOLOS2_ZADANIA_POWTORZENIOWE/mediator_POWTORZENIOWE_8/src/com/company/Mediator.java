package com.company;

import java.util.ArrayList;

public class Mediator {
//    private ArrayList<Osoba> osobaArrayList = new ArrayList<>();
//
//    public void addOsoba(Osoba osoba){
//        this.osobaArrayList.add(osoba);
//    }

    public void notifyMatka(Osoba osoba, String oldDataurodzenia){
        String msg = "Moje dziecko urodzilo sie nie " + oldDataurodzenia + ", a  " + osoba.getDataurodzenia();
        osoba.getMatka().notify(msg);
    }

    public void notifyRodzice(Osoba osoba, String oldImieinazwisko){
        String msg = "Obecnie " + oldImieinazwisko + " nazywa się " + osoba.getImieinazwisko();
        osoba.getMatka().notify(msg);
        osoba.getOjciec().notify(msg);
    }

    public void notifyDzieci(Osoba osoba, Osoba dziecko){
        for(Osoba dzieci : osoba.getDzieci()){
            if(dzieci.getImieinazwisko().equals(dziecko.getImieinazwisko())) continue;
            String msg = "Mam nowe rodzenstwo " + dziecko.getImieinazwisko();
            dzieci.notify(msg);
        }
    }
}
