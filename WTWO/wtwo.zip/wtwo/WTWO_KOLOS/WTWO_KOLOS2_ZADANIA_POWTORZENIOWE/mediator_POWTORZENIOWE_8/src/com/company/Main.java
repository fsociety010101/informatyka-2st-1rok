package com.company;

public class Main {

    public static void main(String[] args) {
        Mediator mediator = new Mediator();


	    Osoba m = new Osoba("Matka Macocha", "10.10.1990", mediator);
	    Osoba o = new Osoba("Ojciec Ojcowski", "10.10.1980", mediator);
	    Osoba ja = new Osoba("Ja Jakubowski", "10.10.1999", mediator);
	    Osoba d1 = new Osoba("Leksi", "30.07.2020", mediator);

	    ja.setMatka(m);
	    ja.setOjciec(o);
	    ja.addDziecko(d1);
        System.out.println("\n\n");
	    ja.setImieinazwisko("Jakub S");
        System.out.println("\n\n");
        ja.setDataurodzenia("25.11.1999");
		System.out.println("\n\n");
		Osoba d2 = new Osoba("Karolinka", "30.10.2013", mediator);
		ja.addDziecko(d2);
    }
}
