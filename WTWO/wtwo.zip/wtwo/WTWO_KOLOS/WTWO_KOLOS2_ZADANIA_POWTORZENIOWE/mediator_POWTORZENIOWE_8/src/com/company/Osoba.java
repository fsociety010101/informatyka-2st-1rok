package com.company;

import java.util.ArrayList;

public class Osoba {
    private String imieinazwisko;
    private String dataurodzenia;

    private Mediator mediator;

    private Osoba matka;
    private Osoba ojciec;
    private ArrayList<Osoba> dzieci;

    public Osoba(String imieinazwisko, String dataurodzenia, Mediator mediator){
        this.imieinazwisko = imieinazwisko;
        this.dataurodzenia = dataurodzenia;
        this.dzieci = new ArrayList<>();
        this.mediator = mediator;
    }

    public void setMatka(Osoba matka) {
        this.matka = matka;
    }

    public void setOjciec(Osoba ojciec) {
        this.ojciec = ojciec;
    }

    public void setImieinazwisko(String imieinazwisko) {
        String oldImieinazwisko = this.imieinazwisko;
        this.imieinazwisko = imieinazwisko;
        mediator.notifyRodzice(this, oldImieinazwisko);
    }

    public void setDataurodzenia(String dataurodzenia) {
        String oldDataurodzenia = this.dataurodzenia;
        this.dataurodzenia = dataurodzenia;
        mediator.notifyMatka(this, oldDataurodzenia);
    }

    public void addDziecko(Osoba osoba) {
        this.dzieci.add(osoba);
        mediator.notifyDzieci(this, osoba);
    }



    public Osoba getMatka() {
        return matka;
    }

    public Osoba getOjciec() {
        return ojciec;
    }

    public ArrayList<Osoba> getDzieci() {
        return dzieci;
    }

    public String getImieinazwisko() {
        return imieinazwisko;
    }

    public String getDataurodzenia() {
        return dataurodzenia;
    }

    public void notify(String message){
        System.out.println(imieinazwisko + ": " + message);
    }
}
