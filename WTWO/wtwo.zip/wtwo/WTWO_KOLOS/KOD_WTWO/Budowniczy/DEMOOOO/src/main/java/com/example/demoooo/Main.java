package com.example.demoooo;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

class a{
    a(int a){}
}

public class Main{
    public static void main(String[] args) {
        a b = new a();
    }
}

