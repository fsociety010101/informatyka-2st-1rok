//package com.example.demoooo;
//
//import javafx.event.ActionEvent;
//import javafx.event.EventHandler;
//import javafx.fxml.FXML;
//import javafx.fxml.FXMLLoader;
//import javafx.fxml.Initializable;
//import javafx.scene.Parent;
//import javafx.scene.Scene;
//import javafx.scene.control.Button;
//import javafx.scene.control.Label;
//import javafx.scene.control.TextField;
//import javafx.stage.Stage;
//
//import java.io.IOException;
//import java.net.Socket;
//import java.net.URL;
//import java.util.ResourceBundle;
//
//public class EntryPanelController implements Initializable {
//    // ENTRY PANEL
//    @FXML
//    private Button button_login;
//    @FXML
//    private Button button_register;
//    @FXML
//    private Label error_msg;
//    @FXML
//    private TextField login;
//    @FXML
//    private TextField password;
//
//    private Client client;
//
//    private String loginText;
//    private String passwordText;
//
//    public EntryPanelController(){}
//
//    @Override
//    public void initialize(URL url, ResourceBundle resourceBundle) {
//
//        button_login.setOnAction(new EventHandler<ActionEvent>() {
//            @Override
//            public void handle(ActionEvent actionEvent) {
//                loginText = login.getText();
//                passwordText = password.getText();
//
//                if(loginText.isEmpty() || passwordText.isEmpty()) {
//                    error_msg.setText("Username or Password is empty");
//                    return;
//                }
//
//                try {
//                    client = new Client(new Socket("localhost", 8189), loginText, passwordText, true);
//                    System.out.println("Connected to server. Write something");
//
//                    FXMLLoader loader = new FXMLLoader(getClass().getResource("sample.fxml"));
//                    Parent root = loader.load();
//
//                    Controller controller = loader.getController();
//                    controller.setClient(client);
//
//                    Stage stage = new Stage();
//                    stage.setScene(new Scene(root));
//                    stage.show();
//                } catch (IOException e){
//                    e.printStackTrace();
//                    System.out.println("Error connecting to server");
//                } catch (Exception e){
//                    error_msg.setText("Bad credentials");
//                }
//            }
//        });
//
//        button_register.setOnAction(new EventHandler<ActionEvent>() {
//            @Override
//            public void handle(ActionEvent actionEvent) {
//                loginText = login.getText();
//                passwordText = password.getText();
//
//                if(loginText.isEmpty() || passwordText.isEmpty()) {
//                    error_msg.setText("Username or Password is empty");
//                    return;
//                }
//
//                try {
//                    client = new Client(new Socket("localhost", 8189), loginText, passwordText, false);
//                    System.out.println("Connected to server. Write something");
//                } catch (IOException e){
//                    e.printStackTrace();
//                    System.out.println("Error connecting to server");
//                } catch (Exception e){
//                    error_msg.setText("This username is already taken");
//                }
//            }
//        });
//    }
//
//    public Client getClient() {
//        return client;
//    }
//}
