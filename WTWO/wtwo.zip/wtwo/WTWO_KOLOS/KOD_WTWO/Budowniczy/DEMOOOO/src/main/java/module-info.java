module com.example.demoooo {
    requires javafx.controls;
    requires javafx.fxml;
    requires json.simple;
    requires gson;


    opens com.example.demoooo to javafx.fxml;
    exports com.example.demoooo;
}