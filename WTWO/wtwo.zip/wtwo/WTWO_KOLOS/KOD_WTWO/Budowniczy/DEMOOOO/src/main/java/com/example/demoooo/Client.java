package com.example.demoooo;

import javafx.scene.layout.VBox;

import java.io.*;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.util.Base64;

public class Client {

    private SocketHandler socketHandler;
    private String username;

    public Client(Socket socket, String login, String password, Boolean LogIn) throws Exception{
        try {
            socketHandler = new SocketHandler(socket);

            if(LogIn == true) {
                String result = login(login, password);
                if(result == null)
                    throw new Exception();
            }
            else if(LogIn == false){
                String result = registration(login, password);
                if(result == null)
                    throw new Exception();
            }
            this.username = login;
        } catch (IOException e){
            e.printStackTrace();
            System.out.println("Error creating client");
            closeSocket(socket);
        }
    }

    public String login(String user, String password){

        // Encode login and password and sent to server using PRINT (without new line)
        Base64.Encoder encoder = Base64.getEncoder();
        socketHandler.getOut().println("Login|" + encoder.encodeToString(user.getBytes(StandardCharsets.UTF_8)) + " " + encoder.encodeToString(password.getBytes(StandardCharsets.UTF_8)));

        // If read value without new line is empty - not logged
        String result = socketHandler.getIn().nextLine();
        if(result.isEmpty()) {
            System.out.println("Bad credentials");
            return null;
        }
        System.out.println("Logged in successfully");
        return user;
    }

    public String registration(String user, String password){

        // Encode login and password and sent to server using PRINT (without new line)
        Base64.Encoder encoder = Base64.getEncoder();
        socketHandler.getOut().println("Register|" + encoder.encodeToString(user.getBytes(StandardCharsets.UTF_8)) + " " + encoder.encodeToString(password.getBytes(StandardCharsets.UTF_8)));

        // If read value (without new line as well) is empty - not logged
        String result = socketHandler.getIn().nextLine();
        if(result.isEmpty()) {
            System.out.println("This username is already taken");
            return null;
        }
        System.out.println("Registered successfully");
        System.out.println("Username: " + user);
        System.out.println("Password: " + password);
        return user;
    }

    // Sending messages to server
    public void sendMessageToServer(String messageToServer){
        socketHandler.getOut().println(messageToServer);
    }

    // Receiving messages from server
    public void receiveMessageFromServer(VBox vBox){
        new Thread(new Runnable() {
            @Override
            public void run() {
                while (socketHandler.getIn().hasNextLine()) {
                    String messageFromServer = socketHandler.getIn().nextLine();
                    Controller.addLabel(messageFromServer, vBox);
                }
            }
        }).start();
    }

    // Method closes socket
    private void closeSocket(Socket socket){
        try{
            if(socket != null)
                socket.close();
        } catch (IOException e){
            e.printStackTrace();
        }
    }

    public String getUsername() {
        return username;
    }
}