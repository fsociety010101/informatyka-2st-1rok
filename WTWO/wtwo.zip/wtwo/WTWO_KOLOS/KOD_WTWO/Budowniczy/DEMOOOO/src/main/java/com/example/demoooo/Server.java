package com.example.demoooo;

import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.URL;
import java.net.URLConnection;
import java.util.*;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;


import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

public class Server {
    // Path to file with credentials in JSON
    private static final String credentialsPath = "C:\\Users\\48730\\Desktop\\KOD_WTWO\\Budowniczy\\DEMOOOO\\src\\main\\java\\com\\example\\demoooo\\credentials.json";

    // List of users' sockets
    private static List<SocketHandler> usersSocketHandlerList;

    // Server socket
    private static ServerSocket server;

    public static void runEntryServer() throws IOException {
        System.out.println("RUNNING: entry server");

        // Idk what it is
        ExecutorService executor = Executors.newCachedThreadPool();

        // Endlessly accept new users and authenticate them
        while(true){
            // Accept new user
            Socket newUser = server.accept();
            System.out.println("New user connected");

            // Create new user's socket handler
            SocketHandler newUserSocketHandler = new SocketHandler(newUser);

            synchronized (usersSocketHandlerList) {
                // Add new user's socket handler to the list
                usersSocketHandlerList.add(newUserSocketHandler);
                System.out.println("Users list size :" + usersSocketHandlerList.size());
            }

            executor.execute(new Runnable() {
                @Override
                public void run() {
                    while(newUserSocketHandler.getIn().hasNextLine()) {
                        String msg = newUserSocketHandler.getIn().nextLine();
                        String [] line = msg.split("\\|");

                        if (msg.toLowerCase(Locale.ROOT).equals("pogoda")){
                            String weather = getWeather();
                            newUserSocketHandler.getOut().println("Server: " + weather);

                        } else if (line[0].equals("Login")) {
                            // Check credentials here
                            String logged = login(line[1]);
                            // Return any non empty string if logged
                            if (logged != null) {
                                System.out.println("New user logged in");
                                newUserSocketHandler.setUsername(logged);
                                newUserSocketHandler.getOut().println("Logged in");
                            } else {
                                System.out.println("New user not logged in");
                                newUserSocketHandler.getOut().println("");
                            }
                        } else if (line[0].equals("Register")) {
                            // Check credentials here
                            String registered = register(line[1]);
                            // Return any non empty string if logged
                            if (registered != null) {
                                System.out.println("New user created and connected");
                                newUserSocketHandler.setUsername(registered);
                                newUserSocketHandler.getOut().println("Registered");
                            } else {
                                System.out.println("New user not registered");
                                newUserSocketHandler.getOut().println("");
                            }
                        } else {
                            for (int i = 0; i < usersSocketHandlerList.size(); i++) {
                                synchronized (usersSocketHandlerList) {
                                    if(newUserSocketHandler != usersSocketHandlerList.get(i))
                                        usersSocketHandlerList.get(i).getOut().println(newUserSocketHandler.getUsername() + ": " + msg);
                                }
                            }
                        }
                    }
                }
            });
        }
    }

    private static String login(String inputCredentials) {
        Base64.Decoder decoder = Base64.getDecoder();
        String[] credentials = inputCredentials.split(" ");
        String user = new String(decoder.decode(credentials[0]));
        String password = new String(decoder.decode(credentials[1]));

        JSONObject jo = new JSONObject();

        try {
            jo = (JSONObject) new JSONParser().parse(new FileReader(credentialsPath));
        } catch(Exception e){
            e.printStackTrace();
            System.out.println("Error fetching credentials");
        }

        if(!usersSocketHandlerList.isEmpty()) {
            for (SocketHandler socketHandler : usersSocketHandlerList)
                if (socketHandler.getUsername() != null && socketHandler.getUsername().equals(user))
                    return null;
        }

        if (password.equals(jo.get(user)))
            return user;
        return null;
    }

    private static String register(String inputCredentials){
        Base64.Decoder decoder = Base64.getDecoder();
        String[] credentials = inputCredentials.split(" ");
        String user = new String(decoder.decode(credentials[0]));
        String password = new String(decoder.decode(credentials[1]));



        JSONObject jo = new JSONObject();

        try {
            jo = (JSONObject) new JSONParser().parse(new FileReader(credentialsPath));
        } catch(Exception e){
            e.printStackTrace();
        }

        // If no existing user with this username was found - accept
        if (jo.get(user) == null) {
            jo.put(user,password);
            FileWriter file = null;
            try {
                file = new FileWriter(credentialsPath);

//                System.out.println(jo.toJSONString());
                // Save new json to file
                synchronized (file){
                    file.write(jo.toJSONString());
                    file.flush();
                    file.close();
                }
            } catch (IOException e) {
                e.printStackTrace();
                System.out.println("Error saving new credentials");
            }
            return user;
        }
        return null;
    }

    public static void main(String[] args) throws IOException {
        usersSocketHandlerList = Collections.synchronizedList(new ArrayList<>());

        server = new ServerSocket(8189);

        // Create thread of entry server
        Thread entryServerThread = new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    runEntryServer();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        });
        entryServerThread.start();
    }

    private static String getWeather(){
        String API_KEY = "fbb339920ef07edcedc3573de7f84530";
        String LOCATION = "Warsaw,PL";
        String urlString = "http://api.openweathermap.org/data/2.5/weather?q=" + LOCATION + "&appid=" + API_KEY + "&units=metric";
        String result = "";
        try{
//            StringBuilder result = new StringBuilder();
            URL url = new URL(urlString);
            URLConnection urlConnection = url.openConnection();
            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(urlConnection.getInputStream()));
            String line;
            while((line = bufferedReader.readLine()) != null){
                result += line;
            }
            bufferedReader.close();

            Map<String, Object> resultMap = jsonToMap(result.toString());
            Map<String, Object> mainMap = jsonToMap(resultMap.get("main").toString());

            result = "\nTemperatura " + mainMap.get("temp") + "°C\n" +
                    "Temp. odczuwalna " + mainMap.get("feels_like") + "°C\n" +
                    "Temp. minimalna " + mainMap.get("temp_min") + "°C\n" +
                    "Temp. maksymalna " + mainMap.get("temp_max") + "°C\n" +
                    "Wilgotność " + mainMap.get("humidity") + "%\n" +
                    "Ciśnienie " + mainMap.get("pressure") + "hPa";



        } catch (IOException e){
            e.printStackTrace();
        }
        return result;
    }

    public static Map<String,Object> jsonToMap(String str){
        return new Gson().fromJson(str, new TypeToken<HashMap<String, Object>>(){}.getType());
    }
}
