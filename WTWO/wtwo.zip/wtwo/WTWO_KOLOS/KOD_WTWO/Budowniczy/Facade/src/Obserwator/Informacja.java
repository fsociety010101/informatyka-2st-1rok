package Obserwator;

public enum Informacja {
    IMIENAZWISKO,DATA,DZIECI
}
