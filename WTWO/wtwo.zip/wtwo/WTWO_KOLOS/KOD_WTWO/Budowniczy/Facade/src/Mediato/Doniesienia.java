package Mediato;

public class Doniesienia {
    String doniesienia;

    public Doniesienia(String doniesienia) {
        this.doniesienia = doniesienia;
    }

    public String getDoniesienia() {
        return doniesienia;
    }
}
