package Obserwator;

public interface Observer {
    void update(Informacja informacja);
}
