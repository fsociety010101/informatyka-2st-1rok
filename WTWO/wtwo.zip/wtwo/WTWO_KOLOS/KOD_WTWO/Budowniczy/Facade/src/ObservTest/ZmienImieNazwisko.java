package ObservTest;

import ObservTest.Observer;
import ObservTest.Osoba;

public class ZmienImieNazwisko implements Observer {

    private String newImie="a";
    private String newNazwisko="b";

    @Override
    public void update(Osoba osoba) {
        String a = osoba.getName();
        String b = osoba.getSurname();
        System.out.println("{newImie} {newNazwisko}: Obecnie {newImie} {newNazwisko} nazywa sie {a} {b}");

        newImie = a;
        newNazwisko = b;
    }

    public void getDane(){
        System.out.println("Data: "+newImie+" "+newNazwisko);
    }
}
