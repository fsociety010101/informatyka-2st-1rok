package Mediato;

public class PierwszaArmia {
    KwateraGlownaMediator mediator;

    public PierwszaArmia(KwateraGlownaMediator mediator) {
        this.mediator = mediator;
    }

    public void wykonajRozkaz(){
        String temp = "";

        Informacja informacja = new Informacja("Atakujemy lewą flankę.");
        mediator.informacjaPraca(informacja);
    }
}
