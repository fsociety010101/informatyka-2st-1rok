package ObservTest;

import ObservTest.Mama;
import ObservTest.Observer;
import ObservTest.Osoba;

public class ZmienImieDate implements Observer {

    private String newData="10.10.2022";

    @Override
    public void update(Osoba osoba) {
        String a = osoba.getDate();

        Mama m = osoba.getMama();
        m.informuj();

        System.out.println("{newImie} {newNazwisko}:Moje dziecko urodzilo sie nie {newData}, a {a}");
        newData = a;
    }

    public void getDane(){
        System.out.println("Data: "+newData);
    }
}
