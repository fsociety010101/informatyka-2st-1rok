package ObservTest;

public class Main {
    public static void main(String args[]){
        Mama mama = new Mama();
        ZmienImieDate zmienImieDate =new ZmienImieDate();
        ZmienImieDzieci zmienImieDzieci = new ZmienImieDzieci();

        mama.subscribe(zmienImieDate);
        mama.subscribe(zmienImieDzieci);

        mama.informuj();

        zmienImieDate.getDane();
    }
}
