package Mediato;

public class DrugaArmia {
    KwateraGlownaMediator mediator;

    public DrugaArmia(KwateraGlownaMediator mediator) {
        this.mediator = mediator;
    }

    public void wykonajRozkaz(){
        String temp = "";

        Informacja informacja = new Informacja("Atakujemy lewą flankę.");
        mediator.informacjaPraca(informacja);
    }
}
