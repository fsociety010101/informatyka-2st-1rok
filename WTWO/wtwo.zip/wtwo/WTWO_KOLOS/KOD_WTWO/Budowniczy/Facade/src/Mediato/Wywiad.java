package Mediato;

public class Wywiad {
    KwateraGlownaMediator mediator;

    public Wywiad(KwateraGlownaMediator mediator) {
        this.mediator = mediator;
    }

    public void wykonajRozkaz(){
        String temp = "";

        Informacja informacja = new Informacja("Wróg planuje ruch na wschód.");
        mediator.informacjaPraca(informacja);
    }
}
