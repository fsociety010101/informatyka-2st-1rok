package ObservTest;

public class Mama extends PersonManager {

    public void informuj(){
        this.notify(new Osoba("a","v","v"));
    }
}
