package Mediato;

public class KwateraGlownaMediator {
    RozkazLeader leader;
    PierwszaArmia pierwszaArmia;
    DrugaArmia drugaArmia;
    CentrumDowodzenia centrumDowodzenia;
    Wywiad wywiad;

    public KwateraGlownaMediator() {
    }

    public void setPierwszaArmia(PierwszaArmia pierwszaArmia) {
        this.pierwszaArmia = pierwszaArmia;
    }

    public void setDrugaArmia(DrugaArmia drugaArmia) {
        this.drugaArmia = drugaArmia;
    }

    public void setCentrumDowodzenia(CentrumDowodzenia centrumDowodzenia) {
        this.centrumDowodzenia = centrumDowodzenia;
    }

    public void setWywiad(Wywiad wywiad) {
        this.wywiad = wywiad;
    }

    public void informacjaPraca(Informacja informacja){
        leader.(informacja);
    }
}
