package Mediato;

public class Rozkazy{
    String rozkaz;

    public Rozkazy(String rozkaz) {
        this.rozkaz = rozkaz;
    }

    public String getRozkaz() {
        return rozkaz;
    }
}
