package Mediato;

import java.util.HashMap;

public class RozkazLeader {
    KwateraGlownaMediator mediator;
    HashMap<String, Integer> publicationCounter = new HashMap<>();

    public RozkazLeader(KwateraGlownaMediator mediator) {
        this.mediator = mediator;
    }

    public void update(Informacja informacja) {
        if (publicationCounter.containsKey(informacja.getInf())) {
            publicationCounter.put(informacja.getInf(), publicationCounter.get(informacja.getInf()) + 1);
        } else {
            publicationCounter.put(informacja.getInf(), 1);
        }
    }

    public String whoIsTheLeader(){
        Integer leaderCounter = 0;
        String leader = "";
        for(String newspaper: publicationCounter.keySet()){
            if (publicationCounter.get(newspaper) > leaderCounter){
                leader = newspaper;
                leaderCounter = publicationCounter.get(newspaper);
            }
        }
        return leader;
    }
}
