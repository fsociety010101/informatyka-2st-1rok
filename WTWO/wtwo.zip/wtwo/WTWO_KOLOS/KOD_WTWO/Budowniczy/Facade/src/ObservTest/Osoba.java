package ObservTest;

import ObservTest.Mama;

public class Osoba {
    private String name;
    private String surname;
    private String date;

    private Mama mama;

    public Osoba(String name, String surname, String date) {
        this.name = name;
        this.surname = surname;
        this.date = date;
    }

    public Mama getMama() {
        return mama;
    }

    public void setMama(Mama mama) {
        this.mama = mama;
    }

    public String getName() {
        return name;
    }

    public String getSurname() {
        return surname;
    }

    public String getDate() {
        return date;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setSurname(String surname) {
        this.surname = surname;
    }

    public void setDate(String date) {
        this.date = date;
    }
}
