package ObservTest;

import ObservTest.Mama;
import ObservTest.Osoba;

public class Person extends PersonManager {

    Mama mama;

    public Person(Mama mama) {
        this.mama = mama;
    }

    public void informuj(){
        this.notify(new Osoba("a","v","v"));
    }
}
