package ObservTest;

import ObservTest.Observer;
import ObservTest.Osoba;

import java.util.ArrayList;
import java.util.List;

public abstract class PersonManager {

    private List<Observer> observers = new ArrayList<>();

    public void subscribe(Observer observer){
        observers.add(observer);
    }

    public void unsubscribe(Observer observer){
        observers.remove(observer);
    }

    public void notify(Osoba osoba){
        for(Observer observer: observers){
            observer.update(osoba);
        }
    }
}
