package Obserwator;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public abstract class Producer {
    Map<Informacja, ArrayList<Observer>> observers = new HashMap<>();

    public void subscribe(Observer observer,Informacja informacja){
        if(observers.containsKey(informacja))
            observers.get(informacja).add(observer);
        else{
            ArrayList<Observer> a = new ArrayList<>();
            a.add(observer);
            observers.put(informacja,a);
        }
    }

    public void notify(Informacja informacja){

    }
}
