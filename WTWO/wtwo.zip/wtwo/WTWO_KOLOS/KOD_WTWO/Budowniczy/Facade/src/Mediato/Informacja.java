package Mediato;

public class Informacja {
    String inf;

    public Informacja(String inf) {
        this.inf = inf;
    }

    public String getInf() {
        return inf;
    }

    public void setInf(String inf) {
        this.inf = inf;
    }
}
