package Mediato;

import java.util.HashMap;

public class CentrumDowodzenia {
    KwateraGlownaMediator mediator;

    public CentrumDowodzenia(KwateraGlownaMediator mediator) {
        this.mediator = mediator;
    }

    public void wykonajRozkaz(){
        String temp = "";

        Informacja informacja = new Informacja("Atakuj tyły wroga.");
        mediator.informacjaPraca(informacja);
    }
}
