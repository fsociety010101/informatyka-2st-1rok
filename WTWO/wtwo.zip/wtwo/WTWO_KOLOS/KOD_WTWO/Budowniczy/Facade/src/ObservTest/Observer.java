package ObservTest;

public interface Observer {
    void update(Osoba osoba);
}
