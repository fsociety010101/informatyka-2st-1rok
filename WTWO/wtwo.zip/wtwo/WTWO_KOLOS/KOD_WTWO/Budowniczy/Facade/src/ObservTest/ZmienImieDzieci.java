package ObservTest;

import ObservTest.Observer;
import ObservTest.Osoba;

public class ZmienImieDzieci implements Observer {
    @Override
    public void update(Osoba osoba) {
        String a = osoba.getName()+osoba.getSurname();
        System.out.println("{newImie} {newNazwisko}:Mam nowe rodzenstwo {a}");
    }
}
