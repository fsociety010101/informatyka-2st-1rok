package sample;

import javafx.scene.layout.VBox;

import java.io.*;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.Scanner;

public class Client {


//    public static void main(String[] args) {
//        try{
//            Socket s = new Socket("localhost",8189);
//            SocketHandler sh = new SocketHandler(s);
//            Scanner sckeyboeard = new Scanner(System.in);
//
//            // Authenticate user, if returns false - user decided not to log in
//            if(!login(sh))
//                System.exit(1);
//
//            Thread th1 = new Thread(new Runnable() {
//                @Override
//                public void run() {
//                    String temp = "";
//                    while(true){
//                        //z klawiatury na serwer:
//                        temp = sckeyboeard.nextLine();
//                        if(temp.equals("bye"))
//                            System.exit(0);
//                        else if(temp.equals("pogoda"))
//                            //add api weather
//                            System.exit(0);
//
//                        sh.getOut().println(temp);
//                    }
//                }
//            });
//
//
//
//            Thread th2 = new Thread(new Runnable() {
//                @Override
//                public void run() {
//                    while(true)
//                        //z serwera na ekran:
//                        System.out.println(sh.getIn().nextLine());
//                }
//            });
//            th1.start();
//            th2.start();
//        } catch (IOException e) {
//            e.printStackTrace();
//        }
//    }
//
//    public static boolean login(SocketHandler sh){
//        Scanner scanner = new Scanner(System.in);
//
//        String user = "";
//        String password = "";
//
//        // Get login
//        System.out.print("Podaj login: ");
//        do {
//            user = scanner.nextLine();
//        } while (user.isEmpty());
//
//        // Get password
//        System.out.print("Podaj hasło: ");
//        do {
//            password = scanner.nextLine();
//        } while (password.isEmpty());
//
//        // Encode login and password and sent to server using PRINT (without new line)
//        Base64.Encoder encoder = Base64.getEncoder();
//        sh.getOut().println("Creds: " + encoder.encodeToString(user.getBytes(StandardCharsets.UTF_8)) + " " + encoder.encodeToString(password.getBytes(StandardCharsets.UTF_8)));
//
//        // If read value (without new line as well) is empty - not logged
//        String result = sh.getIn().nextLine();
//        if(result.isEmpty())
//            return false;
//        return true;
//    }














    private Socket socket;
    private BufferedReader bufferedReader;
    private BufferedWriter bufferedWriter;
    private SocketHandler socketHandler;
    private Scanner scanner;

    public Client(Socket socket){
        try {
            socket = socket;
            bufferedReader = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            bufferedWriter = new BufferedWriter(new OutputStreamWriter(socket.getOutputStream()));
            socketHandler = new SocketHandler(socket);
            scanner = new Scanner(System.in);

            // Read request for 0 - login, 1 - registration
            int choice = 0;
            while(choice != 0 && choice != 1){
                System.out.println("Wybierz akcję [0 - logowanie / 1 - rejestracja]. Wpisz numer");
                String line = scanner.nextLine();

                try{
                    choice = Integer.parseInt(line);
                } catch (NumberFormatException e){
                    System.out.println("Niepoprawna wartość. Wybierz akcję [0 - logowanie / 1 - rejestracja]. Wpisz numer");
                }

                if(choice != 0 || choice != 1)
                    break;

                System.out.println("Niepoprawna wartość. Wybierz akcję [0 - logowanie / 1 - rejestracja]. Wpisz numer");
            }


            if(choice == 0 && !login(socketHandler))
                System.exit(1);
            else if(choice == 1 && !registration(socketHandler))
                System.exit(1);

            Thread th1 = new Thread(new Runnable() {
                @Override
                public void run() {
                    String temp = "";
                    while(true){
                        //z klawiatury na serwer:
                        temp = scanner.nextLine();
                        if(temp.equals("bye"))
                            System.exit(0);
                        else if(temp.equals("pogoda"))
                            //add api weather
                            System.exit(0);

                        socketHandler.getOut().println(temp);
                    }
                }
            });

            Thread th2 = new Thread(new Runnable() {
                @Override
                public void run() {
                    while(true)
                        //z serwera na ekran:
                        System.out.println(socketHandler.getIn().nextLine());
                }
            });
            th1.start();
            th2.start();

        } catch (IOException e){
            e.printStackTrace();
            System.out.println("Error creating client");
            closeEverything(socket,bufferedReader,bufferedWriter);
        }
    }

    public static boolean login(SocketHandler sh){
        Scanner scanner = new Scanner(System.in);

        String user = "";
        String password = "";

        // Get login
        System.out.print("Podaj login: ");
        do {
            user = scanner.nextLine();
        } while (user.isEmpty());

        // Get password
        System.out.print("Podaj hasło: ");
        do {
            password = scanner.nextLine();
        } while (password.isEmpty());

        // Encode login and password and sent to server using PRINT (without new line)
        Base64.Encoder encoder = Base64.getEncoder();
        sh.getOut().println("Login|" + encoder.encodeToString(user.getBytes(StandardCharsets.UTF_8)) + " " + encoder.encodeToString(password.getBytes(StandardCharsets.UTF_8)));

        // If read value (without new line as well) is empty - not logged
        String result = sh.getIn().nextLine();
        if(result.isEmpty())
            return false;
        return true;
    }

    public static boolean registration(SocketHandler sh){
        Scanner scanner = new Scanner(System.in);

        String user = "";
        String password = "";

        // Get login
        System.out.print("Podaj login: ");
        do {
            user = scanner.nextLine();
        } while (user.isEmpty());

        // Get password
        System.out.print("Podaj hasło: ");
        do {
            password = scanner.nextLine();
        } while (password.isEmpty());

        // Encode login and password and sent to server using PRINT (without new line)
        Base64.Encoder encoder = Base64.getEncoder();
        sh.getOut().println("Register|" + encoder.encodeToString(user.getBytes(StandardCharsets.UTF_8)) + " " + encoder.encodeToString(password.getBytes(StandardCharsets.UTF_8)));

        // If read value (without new line as well) is empty - not logged
        String result = sh.getIn().nextLine();
        if(result.isEmpty())
            return false;
        return true;
    }

    public void sendMessageToServer(String messageToServer){
        try{
            bufferedWriter.write(messageToServer);
            bufferedWriter.newLine();
            bufferedWriter.flush();
        } catch (IOException e){
            e.printStackTrace();
            System.out.println("Error sending message to server");
            closeEverything(socket,bufferedReader, bufferedWriter);
        }
    }

    public void receiveMessageFromServer(VBox vBox){
        new Thread(new Runnable() {
            @Override
            public void run() {
                while(socket.isConnected()){
                    try{
                        String messageFromServer = bufferedReader.readLine();
                        Controller.addLabel(messageFromServer, vBox);
                    } catch (IOException e){
                        e.printStackTrace();
                        System.out.println("Error receiving message from the server");
                        closeEverything(socket, bufferedReader, bufferedWriter);
                        break;
                    }
                }
            }
        }).start();
    }

    public void closeEverything(Socket socket, BufferedReader bufferedReader, BufferedWriter bufferedWriter){
        try{
            if(bufferedReader != null)
                bufferedReader.close();

            if(bufferedWriter != null)
                bufferedWriter.close();

            if(socket != null)
                socket.close();

        } catch (IOException e){
            e.printStackTrace();
        }
    }
}