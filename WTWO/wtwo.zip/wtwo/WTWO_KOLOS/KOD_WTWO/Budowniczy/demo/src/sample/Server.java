package sample;

import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.*;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

public class Server {
    // Path to file with credentials in JSON
    private static final String credentialsPath = "C:\\Users\\Ja Kub\\Desktop\\repetyt1 — kopia\\repetyt1\\src\\credentials.json";
//    private static final String credentialsPath = System.getProperty("user.dir") + "credentials.json";


    // List of unauthorized users' sockets
    private static List<SocketHandler> unauthorizedUsersSocketHandlerList;
    // List of authorized users' sockets
    private static List<SocketHandler> authorizedUsersSocketHandlerList;

    // Server socket to authenticate users
    private static ServerSocket entryServer;
    // Server socket for messenger
    private static ServerSocket mainServer;

    public static void runEntryServer() throws IOException {
        System.out.println("RUNNING: entry server");

        // Idk what it is
        ExecutorService executor = Executors.newCachedThreadPool();

        // Endlessly accept new users and authenticate them
        while(true){
            // Accept new user
            Socket newUser = entryServer.accept();
            System.out.println("New user connected");

            // Create new user's socket handler
            SocketHandler newUserSocketHandler = new SocketHandler(newUser);

            synchronized (unauthorizedUsersSocketHandlerList) {
                // Add new user's socket handler to the list
                unauthorizedUsersSocketHandlerList.add(newUserSocketHandler);
                System.out.println("Unauthorized users list size :" + unauthorizedUsersSocketHandlerList.size());
            }

            executor.execute(new Runnable() {
                @Override
                public void run() {
                    while(true) {
                        for(SocketHandler socketHandler : unauthorizedUsersSocketHandlerList) {
                            if (socketHandler.getIn().hasNextLine()) {
                                String [] line = socketHandler.getIn().nextLine().split("\\|");

                                if(line[0].equals("Login")){
                                    // Check credentials here
                                    String logged = login(line[1]);
                                    // Return any non empty string if logged
                                    if (logged != null) {
                                        System.out.println("New user connected");
                                        socketHandler.getOut().println("Logged in");
                                        socketHandler.getOut().println("You have connected with " + socketHandler.getSocket().getLocalSocketAddress());

                                        // Remove socket handler from unauthorized users list
                                        synchronized (unauthorizedUsersSocketHandlerList) {
                                            unauthorizedUsersSocketHandlerList.remove(socketHandler);
                                            System.out.println("Unauthorized users list size :" + unauthorizedUsersSocketHandlerList.size());
                                        }

                                        // Set username (logged) to socketHandler
                                        socketHandler.setUsername(logged);

                                        // Add socket handler to authorized users list
                                        System.out.println("New user switched");
                                        synchronized (authorizedUsersSocketHandlerList) {
                                            authorizedUsersSocketHandlerList.add(socketHandler);
                                            System.out.println("Authorized users list size :" + authorizedUsersSocketHandlerList.size());
                                        }
                                    } else {
                                        System.out.println("New user not connected");
                                        socketHandler.getOut().println("Not logged in");
                                    }
                                } else if(line[0].equals("Register")){
                                    // Check credentials here
                                    String registered = register(line[1]);
                                    // Return any non empty string if logged
                                    if (registered != null) {
                                        System.out.println("New user created and connected");
                                        socketHandler.getOut().println("Registered");
                                        socketHandler.getOut().println("You have connected with " + socketHandler.getSocket().getLocalSocketAddress());

                                        // Remove socket handler from unauthorized users list
                                        synchronized (unauthorizedUsersSocketHandlerList) {
                                            unauthorizedUsersSocketHandlerList.remove(socketHandler);
                                            System.out.println("Unauthorized users list size :" + unauthorizedUsersSocketHandlerList.size());
                                        }

                                        // Set username (registered) to socketHandler
                                        socketHandler.setUsername(registered);

                                        // Add socket handler to authorized users list
                                        System.out.println("New user switched");
                                        synchronized (authorizedUsersSocketHandlerList) {
                                            authorizedUsersSocketHandlerList.add(socketHandler);
                                            System.out.println("Authorized users list size :" + authorizedUsersSocketHandlerList.size());
                                        }
                                    } else {
                                        System.out.println("New user not connected");
                                        socketHandler.getOut().println("Not logged in");
                                    }
                                }
                            }
                        }
                    }
                }
            });
        }
    }

    public static void runMainServer() throws IOException {
//        System.out.println("RUNNING: main server");
//
//        ExecutorService executor = ExecutorService.newCachedThreadPool();
//
//        // Endlessly broadcast messages
//        while(true){
//
//        }
    }

    private static String login(String inputCredentials) {
        Base64.Decoder decoder = Base64.getDecoder();
        String[] credentials = inputCredentials.split(" ");
        String user = new String(decoder.decode(credentials[0]));
        String password = new String(decoder.decode(credentials[1]));

        JSONObject jo = new JSONObject();

        try {
            jo = (JSONObject) new JSONParser().parse(new FileReader( credentialsPath));
        } catch(Exception e){
            e.printStackTrace();
        }

        if (password.equals(jo.get(user)))
            return user;
        return null;
    }

    private static String register(String inputCredentials){
        Base64.Decoder decoder = Base64.getDecoder();
        String[] credentials = inputCredentials.split(" ");
        String user = new String(decoder.decode(credentials[0]));
        String password = new String(decoder.decode(credentials[1]));

        JSONObject jo = new JSONObject();

        try {
            jo = (JSONObject) new JSONParser().parse(new FileReader( credentialsPath));
        } catch(Exception e){
            e.printStackTrace();
        }

        // If no existing user with this username was found - accept
        if (jo.get(user) == null) {
            jo.put(user,password);
            FileWriter file = null;
            try {
                file = new FileWriter(credentialsPath);

                // Save new json to file
                synchronized (file){
                    file.write(jo.toJSONString());
                }
            } catch (IOException e) {
                e.printStackTrace();
                System.out.println("Unable to save new credentials");
            }

            return user;
        }
        return null;
    }

    public static void main(String[] args) throws IOException {
        System.out.println(credentialsPath);
        unauthorizedUsersSocketHandlerList = Collections.synchronizedList(new ArrayList<>());
        authorizedUsersSocketHandlerList = Collections.synchronizedList(new ArrayList<>());

        entryServer = new ServerSocket(8189);
        mainServer = new ServerSocket(8082);

        // Create thread of entry server
        Thread entryServerThread = new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    runEntryServer();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        });
        entryServerThread.run();

        // Create thread of main server
        Thread mainServerThread = new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    runMainServer();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        });
        mainServerThread.run();








//        List<SocketHandler> socketHandlerList = Collections.synchronizedList(new ArrayList<>());
//
//        ExecutorService executor = Executors.newCachedThreadPool();
//
//        //tworzymy serwer monitorujacy port 8189:
//        ServerSocket s = new ServerSocket(8189);
//         /*
//         Program oczekuje aż, klient przyłączy się do portu
//         Metoda zwróci klasę Socket reprezentujący utworzone połączenie:
//         */
//        while (true) {
//            Socket incoming = s.accept();
//
//            System.out.println("You are connected");
//         /*
//         Obiekt ten wykorzystujemy do uzyskania
//         strumienia wejsciowego i wyjsciowego:
//         To co klient umiesci w strumieniu wyjsciowym
//         zostanie przeczytane przez serwer ze strumienia wejsciowego
//         i odwrotnie:
//         */
//            SocketHandler socketHandler = new SocketHandler(incoming);
//
//            synchronized (socketHandlerList) {
//                socketHandlerList.add(socketHandler);
//                System.out.println("Size:"+socketHandlerList.size());
//            }
//
//            executor.execute(new Runnable() {
//                @Override
//                public void run() {
//                    while (socketHandler.getIn().hasNextLine()) {
//                        String line = socketHandler.getIn().nextLine();
//                        for (int i=0;i<socketHandlerList.size();i++) {
//                            synchronized (socketHandlerList) {
//                                // It is login request if message has not new line char
//                                // Otherwise it is just message
//
//                                if(line.startsWith("Creds: ")) {
//                                    line = line.split("Creds: ")[1];
//                                    // Check credentials here
//                                    Boolean logged = login(line);
//                                    // Return any non empty string if logged
//                                    if(logged) {
//                                        socketHandlerList.get(i).getOut().println("Logged");
//                                        socketHandler.getOut().println("You connected with " +incoming.getLocalSocketAddress());
//                                    }
//                                    else
//                                        socketHandlerList.get(i).getOut().println("");
//                                    // Send just message
//                                } else{
//                                    socketHandlerList.get(i).getOut().println(line);
//                                }
//                            }
//                        }
//                    }
//                    synchronized (socketHandlerList) {
//                        socketHandlerList.remove(socketHandler);
//                        System.out.println("Size:"+socketHandlerList.size());
//                    }
//                }
//            });
//        }
    }












//
//    private ServerSocket serverSocket;
//    private Socket socket;
//    private BufferedReader bufferedReader;
//    private BufferedWriter bufferedWriter;
//
//    public Server(ServerSocket serverSocket) {
//        try{
//            this.serverSocket = serverSocket;
//            this.socket = serverSocket.accept();
//            this.bufferedReader = new BufferedReader(new InputStreamReader(socket.getInputStream()));
//            this.bufferedWriter = new BufferedWriter(new OutputStreamWriter(socket.getOutputStream()));
//        } catch (IOException e){
//            e.printStackTrace();
//            System.out.println("Error creating server");
//            closeEverything(socket,bufferedReader,bufferedWriter);
//        }
//    }
//
//    public void sendMessageToClient(String messageToClient){
//        try{
//            bufferedWriter.write(messageToClient);
//            bufferedWriter.newLine();
//            bufferedWriter.flush();
//        } catch (IOException e){
//            e.printStackTrace();
//            System.out.println("Error sending message to client");
//            closeEverything(socket,bufferedReader, bufferedWriter);
//        }
//    }
//
//    public void receiveMessageFromClient(VBox vBox){
//        new Thread(new Runnable() {
//            @Override
//            public void run() {
//                while(socket.isConnected()){
//                   try{
//                       String messageFromClient = bufferedReader.readLine();
//                       Controller.addLabel(messageFromClient, vBox);
//                   } catch (IOException e){
//                       e.printStackTrace();
//                       System.out.println("Error receiving message from the client");
//                       closeEverything(socket, bufferedReader, bufferedWriter);
//                       break;
//                   }
//                }
//            }
//        }).start();
//    }
//
//    public void closeEverything(Socket socket, BufferedReader bufferedReader, BufferedWriter bufferedWriter){
//        try{
//            if(bufferedReader != null)
//                bufferedReader.close();
//
//            if(bufferedWriter != null)
//                bufferedWriter.close();
//
//            if(socket != null)
//                socket.close();
//
//        } catch (IOException e){
//            e.printStackTrace();
//        }
//    }
}
