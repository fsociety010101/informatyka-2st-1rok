
public class Main {

	public static void main(String[] args) {
		int array [] = {10,135,2,55,0,153,61,11,297,5};
		
		
		CustomStringDirector cSD = new CustomStringDirector(new MP3());
		
		String str = cSD.generateString(array);
		System.out.println(str);
		
		cSD.changeCustomStringBuilder(new WAV());
		
		str = cSD.generateString(array);
		System.out.println(str);
		
		cSD.changeCustomStringBuilder(new OGG());
		
		str = cSD.generateString(array);
		System.out.println(str);
		
	}

}
