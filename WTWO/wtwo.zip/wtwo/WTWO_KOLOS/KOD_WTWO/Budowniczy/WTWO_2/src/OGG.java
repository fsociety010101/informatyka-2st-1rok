import java.util.Arrays;
import java.util.Base64;

public class OGG implements CustomStringBuilder{
	
	private String result;
	
	@Override
	public void budujNaglowek() {
		result += "OggHeader\n";
	}

	@Override
	public void budujTagi() {
		result += "OggTags\n";
	}

	@Override
	public void budujBody(int[] array) {
		
		for(int i=0; i<array.length; ++i) {
			if(array[i] > 100) array[i] = 100;
			else if(array[i] < -100) array[i] = -100;
		}
		
		String arrayToString = Arrays.toString(array);
		String encoded = Base64.getEncoder().encodeToString(arrayToString.getBytes());
		
		result += encoded + "\n";
	}
	
	@Override
	public void reset() {
		this.result = "";
	}
	
	@Override
	public String getProduct() {
		return this.result;
	}

}
