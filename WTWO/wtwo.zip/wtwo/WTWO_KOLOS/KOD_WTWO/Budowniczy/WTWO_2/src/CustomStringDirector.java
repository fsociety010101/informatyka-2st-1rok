
// Director
public class CustomStringDirector {

	private CustomStringBuilder customStringBuilder;
	
	public CustomStringDirector(CustomStringBuilder customStringBuilder) {
		this.customStringBuilder = customStringBuilder;
	}
	
	public void changeCustomStringBuilder(CustomStringBuilder customStringBuilder) {
		this.customStringBuilder = customStringBuilder;
	}


	//tutaj nie trzeba return product
	public String generateString(int[] array) {
		customStringBuilder.reset();
		customStringBuilder.budujNaglowek();
		customStringBuilder.budujTagi();
		customStringBuilder.budujBody(array);
		return customStringBuilder.getProduct();
	}
}
