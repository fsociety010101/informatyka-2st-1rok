import java.util.Arrays;
import java.util.Base64;

public class MP3 implements CustomStringBuilder {
	
	private String result;
	
	@Override
	public void budujNaglowek() {
		result += "Mp3Header\n";
	}

	@Override
	public void budujTagi() {
		result += "Mp3Tags\n";
	}

	@Override
	public void budujBody(int[] array) {
		
		String arrayToString = Arrays.toString(array);
		String encoded = Base64.getEncoder().encodeToString(arrayToString.getBytes());

		result += encoded + "\n";
	}
	
	@Override
	public void reset() {
		this.result = "";
	}
	
	@Override
	public String getProduct() {
		return this.result;
	}

}