
// Builder (interface)
public interface CustomStringBuilder {
	
	public void budujNaglowek();
	public void budujTagi();
	public void budujBody(int array[]);
	public void reset();
	public String getProduct();
}
