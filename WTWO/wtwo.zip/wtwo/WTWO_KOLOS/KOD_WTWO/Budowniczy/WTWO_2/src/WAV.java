import java.util.Arrays;

public class WAV implements CustomStringBuilder {
	
	private String result;

	@Override
	public void budujNaglowek() {
		result += "WavHeader\n";
	}

	@Override
	public void budujTagi() {
		result += "\n";
	}

	@Override
	public void budujBody(int[] array) {
		
		String arrayToString = Arrays.toString(array);
		
		result += arrayToString + "\n";
	}

	@Override
	public void reset() {
		this.result = "";
	}

	@Override
	public String getProduct() {
		return this.result;
	}

}
