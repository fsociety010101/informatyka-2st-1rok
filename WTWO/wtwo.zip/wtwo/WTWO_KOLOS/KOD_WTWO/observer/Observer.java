package observer;

public interface Observer {

    void update(Article article);
}
