package com.company.composite;

public interface Component {
    int getSize();
}
