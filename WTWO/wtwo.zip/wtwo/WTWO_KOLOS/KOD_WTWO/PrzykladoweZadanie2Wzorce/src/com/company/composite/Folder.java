package com.company.composite;

import com.company.visitor.Visitor;

import java.util.ArrayList;

public abstract class Folder implements Component {
    ArrayList<Component> components;
    String name;

    public Folder(){
        this.components = new ArrayList<>();
    }

    public void addComponent(Component component){
        this.components.add(component);
    }

    public void removeComponent(Component component){
        this.components.remove(component);
    }

    public ArrayList<Component> getComponents() {
        return this.components;
    }
}
