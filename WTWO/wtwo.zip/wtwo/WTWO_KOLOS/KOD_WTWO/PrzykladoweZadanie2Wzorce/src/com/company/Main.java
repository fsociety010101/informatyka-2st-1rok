package com.company;

import com.company.composite.File;
import com.company.visitor.CountFileSizes;
import com.company.visitor.CountFiles;
import com.company.visitor.Visitor;

public class Main {

    public static void main(String[] args) {
        File root = new File("root", 0);
        File f1 = new File("file1", 5);
        File f2 = new File("file2", 15);

        root.addComponent(f1);
        root.addComponent(f2);

        CountFiles cf = new CountFiles();
        CountFileSizes cfs = new CountFileSizes();

        System.out.println(cf.count(root.getComponents()));
        System.out.println(cfs.count(root.getComponents()));
    }
}
