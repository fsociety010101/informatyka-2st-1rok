package com.company.visitor;

import com.company.composite.Component;
import com.company.composite.File;

import java.util.ArrayList;

public interface Visitor {
    int count(ArrayList<Component> components);
}
