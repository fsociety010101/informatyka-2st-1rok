package com.company.visitor;

import com.company.composite.Component;
import com.company.composite.File;

import java.util.ArrayList;

public class CountFileSizes implements Visitor{

    @Override
    public int count(ArrayList<Component> components) {
        int sum = 0;
        for(Component component : components)
            sum += component.getSize();
        return sum;
    }
}
