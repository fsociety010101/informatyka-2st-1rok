package PodatekFabryka;

import Panstwa.Niemcy;

public class NiemcyLiniowy implements Niemcy {
    @Override
    public double getWartoscPodatku(double wartosc) {
        return 0.2*wartosc;
    }
}
