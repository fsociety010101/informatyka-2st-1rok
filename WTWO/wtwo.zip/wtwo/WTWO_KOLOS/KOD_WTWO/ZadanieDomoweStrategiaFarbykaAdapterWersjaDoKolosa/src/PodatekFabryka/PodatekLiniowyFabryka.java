package PodatekFabryka;

import Panstwa.Francja;
import Panstwa.Niemcy;
import Panstwa.Polska;
import Panstwa.USA;

public class PodatekLiniowyFabryka implements PodatekFabryka{
    @Override
    public Francja createPodatekFrancja() {
        return new FrancjaLiniowy();
    }

    @Override
    public Polska createPodatekPolska() {
        return new PolskaLiniowy();
    }

    @Override
    public USA createPodatekUSA() {
        return new USALiniowy();
    }

    @Override
    public Niemcy createPodatekNiemcy() {
        return new NiemcyLiniowy();
    }
}
