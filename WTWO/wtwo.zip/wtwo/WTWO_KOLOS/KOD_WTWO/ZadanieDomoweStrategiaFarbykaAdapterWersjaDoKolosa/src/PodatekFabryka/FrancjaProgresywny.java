package PodatekFabryka;

import Panstwa.Francja;

public class FrancjaProgresywny implements Francja {
    @Override
    public double getWartoscPodatku(double wartosc) {
        if(wartosc <= 40000)
            return 0.3*wartosc;
        return 0.5*wartosc;
    }
}
