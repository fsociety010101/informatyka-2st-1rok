package PodatekFabryka;

import Panstwa.Francja;
import Panstwa.Niemcy;
import Panstwa.Polska;
import Panstwa.USA;

public class PodatekProgresywnyFabryka implements PodatekFabryka{
    @Override
    public Francja createPodatekFrancja() {
        return new FrancjaProgresywny();
    }

    @Override
    public Polska createPodatekPolska() {
        return new PolskaProgresywny();
    }

    @Override
    public USA createPodatekUSA() {
        return new USAProgresywny();
    }

    @Override
    public Niemcy createPodatekNiemcy() {
        return new NiemcyProgresywny();
    }
}
