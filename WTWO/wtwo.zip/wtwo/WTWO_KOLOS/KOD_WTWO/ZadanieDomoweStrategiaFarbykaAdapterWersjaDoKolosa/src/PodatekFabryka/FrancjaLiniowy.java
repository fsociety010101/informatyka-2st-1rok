package PodatekFabryka;

import Panstwa.Francja;

public class FrancjaLiniowy implements Francja {
    @Override
    public double getWartoscPodatku(double wartosc) {
        return 0.3*wartosc;
    }
}
