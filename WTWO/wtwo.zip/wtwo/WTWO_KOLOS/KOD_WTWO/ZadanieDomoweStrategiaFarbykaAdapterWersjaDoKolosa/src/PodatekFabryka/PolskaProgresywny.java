package PodatekFabryka;

import Panstwa.Polska;

public class PolskaProgresywny implements Polska {
    @Override
    public double getWartoscPodatku(double wartosc) {
        if(wartosc <= 10000)
            return 0.18*wartosc;
        return 0.32*wartosc;
    }
}
