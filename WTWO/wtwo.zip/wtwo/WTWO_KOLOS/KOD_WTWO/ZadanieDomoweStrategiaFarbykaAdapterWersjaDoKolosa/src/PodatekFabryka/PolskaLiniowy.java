package PodatekFabryka;

import Panstwa.Polska;

public class PolskaLiniowy implements Polska {
    @Override
    public double getWartoscPodatku(double wartosc) {
        return 0.19*wartosc;
    }
}
