package PodatekFabryka;

import Panstwa.Niemcy;

public class NiemcyProgresywny implements Niemcy {
    @Override
    public double getWartoscPodatku(double wartosc) {
        if(wartosc <= 50000)
            return 0.2*wartosc;
        return 0.5*wartosc;

    }
}
