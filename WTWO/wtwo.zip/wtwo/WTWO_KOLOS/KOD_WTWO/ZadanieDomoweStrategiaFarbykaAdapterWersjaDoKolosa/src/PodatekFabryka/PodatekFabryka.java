package PodatekFabryka;

import Panstwa.Francja;
import Panstwa.Niemcy;
import Panstwa.Polska;
import Panstwa.USA;

public interface PodatekFabryka {
    Francja createPodatekFrancja();
    Polska createPodatekPolska();
    USA createPodatekUSA();
    Niemcy createPodatekNiemcy();
}
