package Main;

import Panstwa.Francja;
import Panstwa.Niemcy;
import Panstwa.Polska;
import Panstwa.USA;
import PodatekFabryka.PodatekFabryka;

public class ApplicationPodatekFabryka {
    private PodatekFabryka podatekFabryka;
    private USA usa;
    private Polska polska;
    private Francja francja;
    private Niemcy niemcy;

    public ApplicationPodatekFabryka(PodatekFabryka podatekFabryka){
        this.podatekFabryka = podatekFabryka;
    }

    public void setPodatekFabryka(PodatekFabryka podatekFabryka){
        this.podatekFabryka = podatekFabryka;
    }

    public void createPodatek(){
        this.usa = this.podatekFabryka.createPodatekUSA();
        this.polska = this.podatekFabryka.createPodatekPolska();
        this.francja = this.podatekFabryka.createPodatekFrancja();
        this.niemcy = this.podatekFabryka.createPodatekNiemcy();
    }

    public void getPolskaPodatek(double wartosc){
        System.out.println("Polska:");
        System.out.println(this.polska.getWartoscPodatku(wartosc));
    }

    public void getUSAPodatek(double wartosc){
        System.out.println("USA:");
        System.out.println(this.usa.getWartoscPodatku(wartosc));
    }

    public void getFrancjaPodatek(double wartosc){
        System.out.println("Francja:");
        System.out.println(this.francja.getWartoscPodatku(wartosc));
    }

    public void getNiemcyPodatek(double wartosc){
        System.out.println("Niemcy:");
        System.out.println(this.niemcy.getWartoscPodatku(wartosc));
    }
}
