package Main;

import Podatek.PodatekKontekst;
import Przedmiot.Przedmiot;

import java.util.ArrayList;

public class Magazyn {
    private ArrayList<Przedmiot> przedmioty;

    public Magazyn(){
        przedmioty = new ArrayList<Przedmiot>();
    }

    public void dodajDoSpisu(Przedmiot przedmiot){
        przedmioty.add(przedmiot);
    }

    public double pobierzWartośćPoOpodatkowaniu(PodatekKontekst podatekKontekst){
        double kwota = obliczKwote();

        return podatekKontekst.obliczPodatek(kwota);
    }

    public double obliczKwote(){
        double kwota = 0;

        for(Przedmiot przedmiot : przedmioty)
            kwota += przedmiot.okreslWartosc();

        return kwota;
    }
}
