package Main;

import Adapter.Adapter;
import Adapter.Waluta;
import Podatek.PodatekKontekst;
import Podatek.PodatekLiniowy;
import Podatek.PodatekProgresywny;
import PodatekFabryka.PodatekLiniowyFabryka;
import PodatekFabryka.PodatekProgresywnyFabryka;
import Przedmiot.Ksiazka;
import Przedmiot.Obraz;
import Przedmiot.Rzezba;

public class Main {
    public static void main(String [] args){
        Magazyn magazyn = new Magazyn();
        magazyn.dodajDoSpisu(new Ksiazka(2017));
        magazyn.dodajDoSpisu(new Obraz(2000));
        magazyn.dodajDoSpisu(new Rzezba(1700, 7));

        System.out.println("Cena bez podatku: " + String.valueOf(magazyn.obliczKwote()));
        double wartosc = magazyn.obliczKwote();

        PodatekKontekst podatekKontekst = new PodatekKontekst(new PodatekLiniowy());
        System.out.println("Podatek liniowy: " + String.valueOf(magazyn.pobierzWartośćPoOpodatkowaniu(podatekKontekst)));

        podatekKontekst.setPodatekStrategia(new PodatekProgresywny());
        System.out.println("Podatek progresywny: " + String.valueOf(magazyn.pobierzWartośćPoOpodatkowaniu(podatekKontekst)));

        System.out.println("Podatki liniowe:");
        ApplicationPodatekFabryka applicationPodatekFabryka = new ApplicationPodatekFabryka(new PodatekLiniowyFabryka());
        applicationPodatekFabryka.createPodatek();
        applicationPodatekFabryka.getPolskaPodatek(wartosc);
        applicationPodatekFabryka.getFrancjaPodatek(wartosc);
        applicationPodatekFabryka.getUSAPodatek(wartosc);
        applicationPodatekFabryka.getNiemcyPodatek(wartosc);

        System.out.println("\n\n");
        System.out.println("Podatki progresywne:");
        applicationPodatekFabryka.setPodatekFabryka(new PodatekProgresywnyFabryka());
        applicationPodatekFabryka.createPodatek();
        applicationPodatekFabryka.getPolskaPodatek(wartosc);
        applicationPodatekFabryka.getFrancjaPodatek(wartosc);
        applicationPodatekFabryka.getUSAPodatek(wartosc);
        applicationPodatekFabryka.getNiemcyPodatek(wartosc);

        System.out.println("\n\n\n");
        Adapter adapter = new Adapter(magazyn);
        System.out.println("W EURO: " + String.valueOf(adapter.pobierzWartośćPoOpodatkowaniu(podatekKontekst, Waluta.EUR)));
        System.out.println("W PLN : " + String.valueOf(adapter.pobierzWartośćPoOpodatkowaniu(podatekKontekst, Waluta.PLN)));
        System.out.println("W USD : " + String.valueOf(adapter.pobierzWartośćPoOpodatkowaniu(podatekKontekst, Waluta.USD)));
    }
}
