package Adapter;

public enum Waluta {
    PLN,USD,EUR
}
