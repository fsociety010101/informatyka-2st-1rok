package Podatek;

public class PodatekProgresywny implements PodatekStrategia{
    @Override
    public double obliczPodatek(double kwota) {
        if(kwota <= 10000)
            return kwota*0.18;
        return kwota*0.32;
    }
}
