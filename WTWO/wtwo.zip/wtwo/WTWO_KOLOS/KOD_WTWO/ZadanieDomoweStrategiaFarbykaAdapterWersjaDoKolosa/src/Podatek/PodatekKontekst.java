package Podatek;

public class PodatekKontekst {
    PodatekStrategia podatekStrategia;

    public PodatekKontekst(PodatekStrategia podatekStrategia){
        this.podatekStrategia = podatekStrategia;
    }

    public void setPodatekStrategia(PodatekStrategia podatekStrategia){
        this.podatekStrategia = podatekStrategia;
    }

    public double obliczPodatek(double kwota){
        return this.podatekStrategia.obliczPodatek(kwota);
    }
}
