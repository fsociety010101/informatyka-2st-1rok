package Podatek;

public class PodatekLiniowy implements PodatekStrategia{
    @Override
    public double obliczPodatek(double kwota) {
        return kwota*0.19;
    }
}
