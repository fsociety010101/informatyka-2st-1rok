package Podatek;

public interface PodatekStrategia {
    public double obliczPodatek(double kwota);
}
