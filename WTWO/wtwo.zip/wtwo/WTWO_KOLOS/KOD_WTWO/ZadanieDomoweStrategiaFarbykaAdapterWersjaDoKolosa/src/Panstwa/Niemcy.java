package Panstwa;

public interface Niemcy {
    double getWartoscPodatku(double wartosc);
}
