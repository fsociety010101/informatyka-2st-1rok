package Panstwa;

public interface USA{
    double getWartoscPodatku(double wartosc);
}
