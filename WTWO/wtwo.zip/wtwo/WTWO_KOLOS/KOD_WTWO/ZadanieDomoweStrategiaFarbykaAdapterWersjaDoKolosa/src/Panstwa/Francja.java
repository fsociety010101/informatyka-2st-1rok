package Panstwa;

public interface Francja {
    double getWartoscPodatku(double wartosc);
}
