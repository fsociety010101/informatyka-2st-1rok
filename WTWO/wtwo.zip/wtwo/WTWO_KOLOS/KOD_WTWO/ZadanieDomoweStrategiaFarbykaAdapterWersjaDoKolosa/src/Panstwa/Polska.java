package Panstwa;

public interface Polska {
    double getWartoscPodatku(double wartosc);
}
