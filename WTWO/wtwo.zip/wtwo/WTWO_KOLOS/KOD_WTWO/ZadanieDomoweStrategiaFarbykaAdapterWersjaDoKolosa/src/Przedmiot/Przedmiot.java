package Przedmiot;

public abstract class Przedmiot {
    public abstract double okreslWartosc();
}
