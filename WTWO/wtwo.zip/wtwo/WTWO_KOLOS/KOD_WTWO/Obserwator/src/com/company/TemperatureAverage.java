package com.company;

// Obserwator
public class TemperatureAverage implements Observer{
    private int temperature = 0;

    @Override
    public void update(TemperatureChange temperatureChange){
        this.temperature = (this.temperature+temperatureChange.getTemperature())/2;
    }

    public int getTemperature() {
        return this.temperature;
    }
}
