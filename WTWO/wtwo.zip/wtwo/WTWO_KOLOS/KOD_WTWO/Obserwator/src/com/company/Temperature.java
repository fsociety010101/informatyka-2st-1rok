package com.company;

import java.util.Random;
import java.util.concurrent.TimeUnit;

public class Temperature {

    public Temperature(){
        run();
    }

    private void run(){
        Random random = new Random();
        while(true){
            TimeUnit.SECONDS.sleep(1);
            int temperature = random.nextInt(60)-30;
            TemperatureChange tp = new TemperatureChange(temperature);
        }
    }
}
