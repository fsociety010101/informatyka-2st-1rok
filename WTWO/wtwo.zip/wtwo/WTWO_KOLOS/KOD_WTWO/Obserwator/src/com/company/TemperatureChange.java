package com.company;

public class TemperatureChange {
    private int temperature;

    public TemperatureChange(int temperature){
        this.temperature = temperature;
    }

    public int getTemperature() {
        return this.temperature;
    }
}
