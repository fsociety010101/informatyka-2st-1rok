package com.company;

public interface Observer {
    void update(TemperatureChange temperatureChange);
}
