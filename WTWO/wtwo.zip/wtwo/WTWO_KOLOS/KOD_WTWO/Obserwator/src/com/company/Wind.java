package com.company;

public class Wind {
}
