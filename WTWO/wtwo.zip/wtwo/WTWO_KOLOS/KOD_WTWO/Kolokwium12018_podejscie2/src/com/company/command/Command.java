package com.company.command;

import com.company.factory.Order;

public interface Command {
    void execute(Order order);
}
