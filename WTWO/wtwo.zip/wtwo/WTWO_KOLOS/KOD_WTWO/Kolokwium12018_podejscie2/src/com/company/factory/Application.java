package com.company.factory;

import com.company.command.Command;
import com.company.factory.products.ArtykulDomIOgrod;
import com.company.factory.products.ArtykulSpozywczy;

public class Application {
    private OrderFactory orderFactory;
    private ArtykulDomIOgrod artykulDomIOgrod;
    private ArtykulSpozywczy artykulSpozywczy;

    public Application(OrderFactory orderFactory){
        this.orderFactory = orderFactory;
    }

    public void setOrderFactory(OrderFactory orderFactory) {
        this.orderFactory = orderFactory;
    }

    public void createDomiOgrod(){
        this.artykulDomIOgrod = this.orderFactory.createArtykulDomIOgrod();
    }

    public void createSpozywczy(){
        this.artykulSpozywczy = this.orderFactory.createArtykulSpozywczy();
    }

    public void getArtykulDomIOgrod(Order order, Command command) {
        artykulDomIOgrod.zlozZamowienie(order, command);
    }

    public void getArtykulSpozywczy(Order order, Command command) {
        artykulSpozywczy.zlozZamowienie(order, command);
    }
}
