package com.company.factory;

import com.company.command.Command;
import com.company.factory.products.ArtykulDomIOgrod;

public class ZamowieniaMultiArtykulDomIOgrod implements ArtykulDomIOgrod {
    @Override
    public void zlozZamowienie(Order order, Command command) {
        command.execute(order);
    }
}
