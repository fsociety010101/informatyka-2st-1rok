package com.company.factory.products;

import com.company.command.Command;
import com.company.factory.Order;

public interface ArtykulDomIOgrod {
    void zlozZamowienie(Order order, Command command);
}
