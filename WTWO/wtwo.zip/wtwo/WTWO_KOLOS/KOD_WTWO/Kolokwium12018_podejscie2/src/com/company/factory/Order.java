package com.company.factory;

import com.company.Post;

public class Order {
    Post[] list;
    int length;
    double rabat;

    public Order(Post[] list, int length, double rabat) {
        this.list = list;
        this.length = length;
        this.rabat = rabat;
    }

    public Post[] getList() {
        return list;
    }

    public int getLength() {
        return length;
    }

    public double getRabat() {
        return rabat;
    }

    public void setList(Post[] list){
        this.list = list;
    }

    public void setLength(int length){
        this.length = length;
    }

    public void setRabat(double rabat){
        this.rabat = rabat;
    }
}
