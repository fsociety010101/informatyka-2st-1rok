package com.company.factory;

import com.company.factory.products.ArtykulDomIOgrod;
import com.company.factory.products.ArtykulSpozywczy;

public class ZamowieniaZUstalonymRabatemFactory implements OrderFactory{

    @Override
    public ArtykulDomIOgrod createArtykulDomIOgrod() {
        return null;
    }

    @Override
    public ArtykulSpozywczy createArtykulSpozywczy() {
        return new ZamowieniaZwykleArtykulSpozywczy();
    }
}
