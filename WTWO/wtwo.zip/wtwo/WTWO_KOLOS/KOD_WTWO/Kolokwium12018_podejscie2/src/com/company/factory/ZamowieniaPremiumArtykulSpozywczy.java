package com.company.factory;

import com.company.command.Command;
import com.company.factory.products.ArtykulSpozywczy;

public class ZamowieniaPremiumArtykulSpozywczy implements ArtykulSpozywczy {
    @Override
    public void zlozZamowienie(Order order, Command command) {
        command.execute(order);
    }
}
