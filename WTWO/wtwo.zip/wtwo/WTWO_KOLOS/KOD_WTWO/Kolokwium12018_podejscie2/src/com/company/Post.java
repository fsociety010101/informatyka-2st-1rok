package com.company;

public class Post {
    private String name;
    private int cena;
    private Typ typ;

    public Post(String name, int cena, Typ typ) {
        this.name = name;
        this.cena = cena;
        this.typ = typ;
    }

    public String getName() {
        return name;
    }

    public int getCena() {
        return cena;
    }

    public Typ getTyp() {
        return typ;
    }
}
