package com.company.command;

import com.company.factory.Order;

public class ZaktualizujRabatCommand implements Command{
    private Receiver receiver;

    @Override
    public void execute(Order order) {
        this.receiver.zaktualizujRabat(order);
    }

    public ZaktualizujRabatCommand(Receiver receiver){
        this.receiver = receiver;
    }
}
