package com.company.command;

import com.company.factory.Order;

public class ZapiszNaLiscieZamowienZrealizowanychCommand implements Command{
    private Receiver receiver;

    @Override
    public void execute(Order order) {
        this.receiver.zapiszNaLiscieZamowienZrealizowanych(order);
    }

    public ZapiszNaLiscieZamowienZrealizowanychCommand(Receiver receiver){
        this.receiver = receiver;
    }
}
