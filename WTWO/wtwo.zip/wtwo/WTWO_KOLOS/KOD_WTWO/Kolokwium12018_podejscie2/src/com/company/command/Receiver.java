package com.company.command;

import com.company.factory.Order;

public class Receiver {
    public void zdejmijZeStanu(Order order){
        System.out.println("ZDEJMIJ ZE STANU");
    }

    public void zaktualizujRabat(Order order){
        System.out.println("ZAKTUALIZUJ RABAT");
    }

    public void zapiszNaLiscieZamowienZrealizowanych(Order order){
        System.out.println("ZAPISZ NA LISCIE");
    }
}
