package com.company;

public enum Typ {
    SPOZYWCZE,DOMiOGROD
}
