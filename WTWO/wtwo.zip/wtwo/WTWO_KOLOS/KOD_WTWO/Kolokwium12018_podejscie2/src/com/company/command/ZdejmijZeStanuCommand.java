package com.company.command;

import com.company.factory.Order;

public class ZdejmijZeStanuCommand implements Command{
    private Receiver receiver;

    @Override
    public void execute(Order order) {
        this.receiver.zdejmijZeStanu(order);
    }

    public ZdejmijZeStanuCommand(Receiver receiver){
        this.receiver = receiver;
    }
}
