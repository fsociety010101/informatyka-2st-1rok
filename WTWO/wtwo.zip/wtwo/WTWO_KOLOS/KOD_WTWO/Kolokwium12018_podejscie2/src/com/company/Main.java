package com.company;

import com.company.command.Command;
import com.company.command.Receiver;
import com.company.command.ZdejmijZeStanuCommand;
import com.company.factory.Application;
import com.company.factory.MultiZamowieniaFactory;
import com.company.factory.Order;

public class Main {
    public static void main(String[] args) {

        Post post1 = new Post("ogloszenie 1", 1000, Typ.SPOZYWCZE);
        Post post2 = new Post("ogloszenie 2", 5000, Typ.SPOZYWCZE);
        Post post3 = new Post("ogloszenie 3", 14000, Typ.SPOZYWCZE);

        Post[] list1 = {post1};
        Post[] list2 = {post1, post2};
        Post[] list3 = {post1, post2, post3};

        Order order1 = new Order(list1, list1.length, .0);
        Order order2 = new Order(list1, list1.length, .5);
        Order order3 = new Order(list2, list2.length, .10);
        Order order4 = new Order(list2, list2.length, .15);
        Order order5 = new Order(list3, list3.length, .20);
        Order order6 = new Order(list3, list3.length, .25);

        Application application = new Application(new MultiZamowieniaFactory());

        Command command = new ZdejmijZeStanuCommand(new Receiver());

        application.createDomiOgrod();
        application.getArtykulDomIOgrod(order1, command);
    }
}
