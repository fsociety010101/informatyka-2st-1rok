package com.company.factory;

import com.company.factory.products.ArtykulDomIOgrod;
import com.company.factory.products.ArtykulSpozywczy;

public interface OrderFactory {
    ArtykulDomIOgrod createArtykulDomIOgrod();
    ArtykulSpozywczy createArtykulSpozywczy();
}
