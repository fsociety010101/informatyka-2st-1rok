package com.company.factory;

import com.company.factory.products.ArtykulDomIOgrod;
import com.company.factory.products.ArtykulSpozywczy;

public class MultiZamowieniaFactory implements OrderFactory{

    @Override
    public ArtykulDomIOgrod createArtykulDomIOgrod() {
        return new ZamowieniaMultiArtykulDomIOgrod();
    }

    @Override
    public ArtykulSpozywczy createArtykulSpozywczy() {
        return null;
    }
}
