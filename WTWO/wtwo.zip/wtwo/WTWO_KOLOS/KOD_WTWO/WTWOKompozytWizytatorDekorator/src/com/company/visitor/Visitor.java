package com.company.visitor;

import com.company.FirmComponent;

public interface Visitor {
    String convertFirm(FirmComponent firmComponent);
}
