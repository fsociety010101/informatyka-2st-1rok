package com.company;

import com.company.decorator.BaseDecorator;
import com.company.decorator.CoNajmniejPolowaCyftJestPodzielnaPrzezTrzy;
import com.company.decorator.NIPzawieraCyfryMMDDtegoDnia;
import com.company.decorator.WszystkieCyfrySaParzyste;
import com.company.visitor.JSONVisitor;
import com.company.visitor.Visitor;
import com.company.visitor.XMLVisitor;

public class Main {

    public static void main(String[] args) {
        FirmLeaf firm1 = new FirmLeaf("Firma1", "Adres1", "NIP1", 10000.0, 15000.0, "");
        FirmLeaf firm2 = new FirmLeaf("Firma2", "Adres2", "NIP2", 15000.0, 3000.0, "");
        FirmLeaf firm3 = new FirmLeaf("Firma3", "Adres3", "NIP3", 9000.0, 109000.0, "");
        FirmLeaf firm4 = new FirmLeaf("Firma4", "Adres4", "NIP4", 100000.0, 1000.0, "");
        FirmLeaf firm5 = new FirmLeaf("Firma5", "Adres5", "NIP5", 9000.0, 109000.0, "");
        FirmLeaf firm6 = new FirmLeaf("Firma6", "Adres6", "NIP6", 100000.0, 1000.0, "");

        firm1.addFirm(firm2);
        firm1.addFirm(firm3);
        firm1.addFirm(firm4);

        firm5.addFirm(firm6);

        firm1.addFirm(firm5);

        FirmComponent firmComponent = new CoNajmniejPolowaCyftJestPodzielnaPrzezTrzy(new NIPzawieraCyfryMMDDtegoDnia(new WszystkieCyfrySaParzyste(null)));

        System.out.println("Suma: " + firmComponent.calculateBonificate(firm1.getNIP()));

        XMLVisitor xmlVisitor = new XMLVisitor();
        System.out.println(xmlVisitor.convertFirm(firm1));

        JSONVisitor jsonVisitor = new JSONVisitor();
        System.out.println(jsonVisitor.convertFirm(firm2));
    }
}
