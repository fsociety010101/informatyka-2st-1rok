package com.company.decorator;

import com.company.FirmComponent;

public class CoNajmniejPolowaCyftJestPodzielnaPrzezTrzy extends BaseDecorator {

    public CoNajmniejPolowaCyftJestPodzielnaPrzezTrzy(FirmComponent firmComponentDecorator) {
        super(firmComponentDecorator);
    }

    @Override
    public double calculateBonificate(String NIP){
        double res = 20;
        if(this.firmComponentDecorator != null)
            res += this.firmComponentDecorator.calculateBonificate(NIP);
        return res;
    }
}