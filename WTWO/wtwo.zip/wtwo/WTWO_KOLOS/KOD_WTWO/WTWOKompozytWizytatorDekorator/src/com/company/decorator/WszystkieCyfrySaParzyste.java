package com.company.decorator;

import com.company.FirmComponent;

public class WszystkieCyfrySaParzyste extends BaseDecorator {

    public WszystkieCyfrySaParzyste(FirmComponent firmComponentDecorator) {
        super(firmComponentDecorator);
    }

    @Override
    public double calculateBonificate(String NIP){
        double res = 30;
        if(this.firmComponentDecorator != null)
            res += this.firmComponentDecorator.calculateBonificate(NIP);
        return res;
    }
}
