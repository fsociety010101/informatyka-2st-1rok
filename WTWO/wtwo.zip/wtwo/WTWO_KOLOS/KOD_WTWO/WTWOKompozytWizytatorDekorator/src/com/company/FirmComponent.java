package com.company;

import java.util.ArrayList;

// Component
public interface FirmComponent {
    double calculateBonificate(String NIP);

}
