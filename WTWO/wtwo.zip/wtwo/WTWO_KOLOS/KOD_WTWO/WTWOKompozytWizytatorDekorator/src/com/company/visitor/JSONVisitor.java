package com.company.visitor;

import com.company.FirmComponent;

public class JSONVisitor implements Visitor{
    @Override
    public String convertFirm(FirmComponent firmComponent) {
        return "JSON: " + firmComponent.getClass();
    }
}
