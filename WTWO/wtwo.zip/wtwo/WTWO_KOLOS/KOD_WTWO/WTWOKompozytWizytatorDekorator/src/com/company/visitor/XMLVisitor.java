package com.company.visitor;

import com.company.FirmComponent;

public class XMLVisitor implements Visitor {
    @Override
    public String convertFirm(FirmComponent firmComponent) {
        return "XML: " + firmComponent.getClass();
    }
}
