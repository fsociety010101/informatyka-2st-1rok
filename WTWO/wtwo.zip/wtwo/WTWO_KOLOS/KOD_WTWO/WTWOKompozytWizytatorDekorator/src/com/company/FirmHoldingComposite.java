package com.company;

import java.util.ArrayList;
import java.util.Random;

public abstract class FirmHoldingComposite implements FirmComponent{

    protected double bonificate;

    protected String name;
    protected String address;
    protected String NIP;

    protected double annualIncome;
    protected double ordinaryIncome;
    protected String rivals;

    protected ArrayList<FirmComponent> heldFirms;

    public FirmHoldingComposite(String name, String address, String NIP, double annualIncome, double ordinaryIncome, String rivals) {
        this.bonificate = 0;
        this.name = name;
        this.address = address;
        this.NIP = NIP;
        this.annualIncome = annualIncome;
        this.ordinaryIncome = ordinaryIncome;
        this.rivals = rivals;
        this.heldFirms = new ArrayList<FirmComponent>();
    }

    public void addFirm(FirmLeaf firmLeaf){
        this.heldFirms.add(firmLeaf);
    }

    public void removeFirm(FirmComponent firmComponent){
        this.heldFirms.remove(firmComponent);
    }

    public ArrayList<FirmComponent> getChildrenFirms(){
        return this.heldFirms;
    }
}
