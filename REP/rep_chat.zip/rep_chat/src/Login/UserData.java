package Login;

public class UserData {
    private String username;
    private String passwordHash;
}